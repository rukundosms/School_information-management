<?php require_once '../header.php'; ?>
                            <h1>Welcome, Admin</h1>
                            <p>Your role: Administrator</p>
                            <?php require_once '../footer.php'; ?>