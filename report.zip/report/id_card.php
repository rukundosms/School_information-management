<?php
include "connection.php";

// Handle AJAX request for students
if (isset($_GET['class_name'])) {
    $class_name = $conn->real_escape_string($_GET['class_name']);
    $response = ["students" => [], "school" => []];
    
    if (!empty($class_name)) {
        // Get students from the id_card table
        $sql = "SELECT student_id, reg_no, first_name, last_name, sex, level, class, 
                       student_photo, academic_year, school_name, school_phone, school_email
                FROM id_card 
                WHERE class = '$class_name' 
                ORDER BY first_name, last_name";
        
        $result = $conn->query($sql);
        
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $response['students'][] = $row;
            }
        }
        
        // Get school info from the first student record (assuming all have same school info)
        if (count($response['students']) > 0) {
            $firstStudent = $response['students'][0];
            $response['school'] = [
                'school_name' => $firstStudent['school_name'],
                'phone' => $firstStudent['school_phone'],
                'email' => $firstStudent['school_email']
            ];
        }
    }
    
    header("Content-Type: application/json");
    echo json_encode($response);
    exit;
}

// Get unique classes for the dropdown
$classes_result = $conn->query("SELECT DISTINCT class, level FROM id_card ORDER BY level, class");
$classes = [];
if ($classes_result && $classes_result->num_rows > 0) {
    while ($row = $classes_result->fetch_assoc()) {
        $classes[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student ID Card Generator</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>

  <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #00bcd4;
            --accent-color: #8e44ad;
            --text-color: #333;
            --light-bg: #f0f4f8;
            --card-shadow: 0 2px 6px rgba(0,0,0,0.08);
            --card-height: 150px; /* Standard ID card height */
            --card-width: 240px;  /* Standard ID card width (credit card size is 85.6mm x 53.98mm) */
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--light-bg);
            padding: 10px;
            margin: 0;
            color: var(--text-color);
            line-height: 1.2;
            font-size: 12px;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 10px;
        }
        
        header {
            text-align: center;
            margin-bottom: 15px;
            padding: 10px 0;
        }
        
        header h1 {
            color: var(--primary-color);
            font-size: 1.5rem;
            margin: 0 0 4px 0;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
        }
        
        header p {
            color: #555;
            margin-top: 2px;
            font-size: 0.85rem;
            text-shadow: 0.5px 0.5px 1px rgba(0,0,0,0.1);
        }
        
        .form-container {
            background: white;
            padding: 10px;
            border-radius: 6px;
            box-shadow: var(--card-shadow);
            margin-bottom: 15px;
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            justify-content: center;
            align-items: center;
        }
        
        select {
            padding: 7px 9px;
            border-radius: 4px;
            border: 1px solid #ddd;
            width: 180px;
            font-size: 0.8rem;
            background: white;
            box-shadow: 0 1px 2px rgba(0,0,0,0.05);
            transition: border-color 0.2s;
        }
        
        select:focus {
            border-color: var(--secondary-color);
            outline: none;
        }
        
        .btn {
            padding: 7px 10px;
            cursor: pointer;
            border: none;
            color: white;
            border-radius: 4px;
            font-size: 0.8rem;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            font-weight: 500;
            text-shadow: 0.5px 0.5px 1px rgba(0,0,0,0.3);
        }
        
        .btn:hover { 
            opacity: 0.9; 
            transform: translateY(-1px);
        }
        
        .btn-print { background: #e74c3c; }
        .btn-pdf { background: #27ae60; }
        .btn-img { background: #3498db; }
        .btn-main { background: var(--accent-color); }
        
        .controls-info {
            text-align: center;
            margin-top: 5px;
            font-size: 0.7rem;
            color: #777;
            width: 100%;
            text-shadow: 0.5px 0.5px 1px rgba(0,0,0,0.1);
        }

        /* ID card container */
        .id-cards-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(var(--card-width), 1fr));
            gap: 12px;
            margin-top: 15px;
        }

        /* ID Card Design - Standard credit card size */
        .id-card {
            width: 100%;
            height: var(--card-height);
            max-width: var(--card-width);
            border: 1px solid var(--primary-color);
            border-radius: 4px;
            overflow: hidden;
            background: white;
            box-shadow: var(--card-shadow);
            margin: 0 auto;
            position: relative;
            display: flex;
            flex-direction: column;
        }
        
        .id-top {
            background: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 3px 5px;
            height: 25px;
            border-bottom: 1px solid #00838f;
            flex-shrink: 0;
        }
        
        .id-top img {
            width: 18px;
            height: 18px;
            object-fit: contain;
            flex-shrink: 0;
        }
        
        .school-details {
            text-align: center;
            font-size: 0.55rem;
            line-height: 1.1;
            flex: 1;
            padding: 0 4px;
        }
        
        .school-details div:first-child {
            font-weight: bold;
            font-size: 0.65rem;
            white-space: nowrap;
            text-shadow: 0.5px 0.5px 1px rgba(0,0,0,0.3);
        }
        
        .school-details div:last-child {
            font-size: 0.5rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            text-shadow: 0.5px 0.5px 1px rgba(0,0,0,0.2);
        }
        
        .id-middle {
            display: flex;
            background: linear-gradient(to bottom, #00bcd4, #0097a7);
            padding: 5px;
            height: calc(var(--card-height) - 25px);
            flex-grow: 1;
        }
        
        .photo-barcode-wrapper {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-right: 6px;
            flex-shrink: 0;
            width: 60px;
        }
        
        .photo-container {
            width: 50px;
            height: 55px;
            overflow: hidden;
            border: 1px solid #00838f;
            border-radius: 2px;
            background: #e0f7fa;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .photo-container img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .barcode-container {
            width: 50px;
            height: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-top: 2px;
            background: white;
            padding: 1px;
            border-radius: 1px;
        }
        
        .barcode-container svg {
            width: 100%;
            height: 100%;
        }
        
        .student-info {
            font-size: 0.6rem;
            color: #000;
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        
        .id-title {
            font-weight: bold;
            text-align: center;
            background: #00838f;
            color: white;
            padding: 1px;
            border-radius: 1px;
            margin-bottom: 3px;
            font-size: 0.65rem;
            text-shadow: 0.5px 0.5px 1px rgba(0,0,0,0.3);
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: auto 1fr;
            gap: 1px 2px;
            margin-bottom: 2px;
        }
        
        .info-label {
            font-weight: bold;
            white-space: nowrap;
            text-shadow: 0.5px 0.5px 1px rgba(0,0,0,0.1);
        }
        
        .info-value {
            text-shadow: 0.5px 0.5px 1px rgba(0,0,0,0.1);
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .signature-area {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            font-size: 0.55rem;
            margin-top: auto;
            padding-top: 2px;
            border-top: 0.5px dotted #00838f;
        }
        
        .signature-area div:first-child {
            font-style: italic;
            margin-bottom: 2px;
        }

        /* Print optimization - 10 cards per page */
        @media print {
            @page { 
                size: landscape; 
                margin: 0.5cm;
            }
            
            body { 
                background: white !important; 
                padding: 0;
                /* -webkit-print-color-adjust: exact;
                color-adjust: exact; */
                font-size: 7pt;
            }
            
            .btn, .form-container, header { 
                display: none !important; 
            }
            
            .container {
                max-width: 100%;
                padding: 0;
                margin: 0;
            }
            
            .id-cards-container {
                display: grid;
                grid-template-columns: repeat(5, 1fr); /* 5 columns */
                grid-template-rows: repeat(2, 1fr);    /* 2 rows */
                gap: 6px;
                margin: 0;
                width: 100%;
                height: 100%;
            }
            
            .id-card {
                max-width: 100%;
                height: 150px;
                page-break-inside: avoid;
                break-inside: avoid;
                border: 1px solid #000;
                box-shadow: none;
            }
        }
        
        /* Responsive styles */
        @media (max-width: 1200px) {
            .id-cards-container {
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            }
        }
        
        @media (max-width: 992px) {
            .id-cards-container {
                grid-template-columns: repeat(auto-fill, minmax(190px, 1fr));
            }
        }
        
        @media (max-width: 768px) {
            header h1 { 
                font-size: 1.3rem; 
            }
            
            header p {
                font-size: 0.75rem;
            }
            
            .form-container {
                flex-direction: column;
                align-items: stretch;
            }
            
            select {
                width: 100%;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
            
            .id-cards-container {
                grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            }
            
            :root {
                --card-height: 155px;
                --card-width: 180px;
            }
            
            .photo-container {
                width: 45px;
                height: 50px;
            }
            
            .barcode-container {
                width: 45px;
                height: 15px;
            }
            
            .photo-barcode-wrapper {
                width: 55px;
            }
            
            .school-details div:last-child {
                font-size: 0.45rem;
            }
        }
        
        @media (max-width: 480px) {
            body {
                padding: 5px;
            }
            
            header h1 { 
                font-size: 1.1rem; 
            }
            
            header p {
                font-size: 0.7rem;
            }
            
            .id-cards-container {
                grid-template-columns: 1fr;
            }
            
            .id-card {
                max-width: 100%;
            }
        }

        /* Loading animation */
        .loading-spinner {
            display: inline-block;
            width: 25px;
            height: 25px;
            border: 2px solid #f3f3f3;
            border-top: 2px solid var(--accent-color);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-bottom: 6px;
            display: none;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
  </style>
</head>
<body>
<div class="container">
  <header>
    <h1><i class="fa-solid fa-id-card"></i> Student ID Card Generator</h1>
    <p>Select a class and generate standard-sized ID cards (10 per page)</p>
  </header>

  <div class="form-container">
    <select id="classSelect">
      <option value="">-- Select a Class --</option>
      <?php
        foreach ($classes as $class) {
            $display_text = "Class {$class['class']} - Level {$class['level']}";
            echo "<option value='{$class['class']}'>$display_text</option>";
        }
      ?>
    </select>
    <button class="btn btn-main" onclick="loadCards()"><i class="fa-solid fa-gears"></i> Generate</button>
    <button class="btn btn-print" onclick="printCards()"><i class="fa-solid fa-print"></i> Print</button>
    <button class="btn btn-pdf" onclick="downloadPDF()"><i class="fa-solid fa-file-pdf"></i> PDF</button>
    <button class="btn btn-img" onclick="downloadImage()"><i class="fa-solid fa-image"></i> Image</button>
    
    <div class="controls-info">
        <p>Optimized for printing 10 standard-sized cards per page (5x2 grid)</p>
    </div>
  </div>

  <div class="id-cards-container" id="idCardsContainer"></div>
</div>

<script>
const { jsPDF } = window.jspdf;

function loadCards() {
  const className = document.getElementById('classSelect').value;
  if (!className) { 
      alert("Please select a class first"); 
      return; 
  }

  // Show loading state
  const container = document.getElementById('idCardsContainer');
  container.innerHTML = `
    <div style="text-align:center; padding: 15px; width: 100%;">
        <div class="loading-spinner"></div>
        <p>Loading students...</p>
    </div>`;
  
  fetch("?class_name=" + encodeURIComponent(className))
    .then(res => res.json())
    .then(data => {
      container.innerHTML = "";
      
      if (data.students.length === 0) {
        container.innerHTML = `
          <div class="no-students" style="text-align: center; padding: 15px; grid-column: 1 / -1;">
            <i class="fas fa-user-slash" style="font-size: 1.5rem; color: #ccc; margin-bottom: 8px;"></i>
            <h3 style="color: #777; font-size: 0.9rem;">No students found for this class</h3>
          </div>`;
        return;
      }
      
      const school = data.school;

      data.students.forEach(stu => {
        const card = document.createElement('div');
        card.className = 'id-card';

        // Use the student_photo path directly from the database
        const studentPhoto = stu.student_photo && stu.student_photo !== '' ? 
                            stu.student_photo : 'images/default.png';
        
        card.innerHTML = `
          <div class="id-top">
            <div class="emblem-left"><img src="images/school.png" width="18" height="18" alt="School Emblem"></div>
            <div class="school-details">
              <div>${school.school_name || 'School Name'}</div>
              <div>${school.phone || 'Phone'} | ${school.email || 'Email'}</div>
            </div>
            <div class="emblem-right"><img src="images/rtb.png" width="18" height="18" alt="Organization Emblem"></div>
          </div>
          <div class="id-middle">
            <div class="photo-barcode-wrapper">
                <div class="photo-container">
                    <img src="${studentPhoto}" alt="Student Photo" onerror="this.src='images/default.png'">
                </div>
                <div class="barcode-container">
                    <svg id="barcode-${stu.student_id}" class="barcode"></svg>
                </div>
            </div>
            <div class="student-info">
                <div class="id-title">STUDENT ID CARD</div>
                <div class="info-grid">
                    <span class="info-label">Name:</span>
                    <span class="info-value">${stu.first_name} ${stu.last_name}</span>
                    <span class="info-label">Sex:</span>
                    <span class="info-value">${stu.sex}</span>
                    <span class="info-label">Reg:</span>
                    <span class="info-value">${stu.reg_no}</span>
                    <span class="info-label">Class:</span>
                    <span class="info-value">${stu.class}</span>
                    <span class="info-label">Level:</span>
                    <span class="info-value">${stu.level}</span>
                    <span class="info-label">Year:</span>
                    <span class="info-value">${stu.academic_year}</span>
                </div>
                <div class="signature-area">
                    <div>............................</div>
                    <div>Signature & Stamp</div>
                </div>
            </div>
          </div>`;

        container.appendChild(card);

        // Generate barcode after the element is rendered
        setTimeout(() => {
          try {
            JsBarcode(`#barcode-${stu.student_id}`, stu.reg_no, {
              format: "CODE128",
              width: 0.8,
              height: 15,
              displayValue: false,
              fontSize: 6,
              margin: 0,
              background: "#fff",
              lineColor: "#000"
            });
          } catch (error) {
            console.error("Barcode generation error:", error);
          }
        }, 30);
      });
    })
    .catch(error => {
      console.error("Error fetching students:", error);
      container.innerHTML = `
        <div style="text-align:center; padding: 15px; color: #e74c3c; grid-column: 1 / -1;">
          <i class="fas fa-exclamation-triangle" style="font-size: 1.2rem; margin-bottom: 8px;"></i>
          <p style="font-size: 0.8rem;">Error loading students. Please try again.</p>
        </div>`;
    });
}

function printCards() {
  const container = document.getElementById('idCardsContainer');
  if (container.children.length === 0) {
    alert("Please generate ID cards first");
    return;
  }
  
  // Create a print-friendly version with 10 cards per page (5x2 grid)
  const printWindow = window.open('', '_blank');
  printWindow.document.write(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Print Student ID Cards</title>
      :root {
  --primary-color: #002147;      /* deep blue navy */
  --secondary-color: #0099cc;    /* cyan accent */
  --accent-color: #ffcc00;       /* gold line accent */
  --text-color: #222;
  --bg-gradient: linear-gradient(145deg, #003366, #005580);
  --light-bg: #eef3f8;
  --card-shadow: 0 3px 8px rgba(0,0,0,0.2);
  --card-width: 240px;
  --card-height: 150px;
}

body {
  font-family: "Poppins", "Segoe UI", sans-serif;
  background: var(--light-bg);
  margin: 0;
  padding: 20px;
  color: var(--text-color);
}

header h1 {
  font-weight: 600;
  color: var(--primary-color);
  letter-spacing: 1px;
}

.form-container {
  background: #fff;
  padding: 10px 15px;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  margin-bottom: 20px;
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 10px;
}

select, .btn {
  font-size: 0.9rem;
}

.btn {
  padding: 7px 14px;
  border: none;
  border-radius: 6px;
  color: #fff;
  font-weight: 500;
  cursor: pointer;
  transition: 0.2s;
}
.btn-main { background: var(--secondary-color); }
.btn-print { background: #e74c3c; }
.btn-pdf { background: #27ae60; }
.btn-img { background: #3498db; }
.btn:hover { transform: translateY(-1px); opacity: 0.9; }

/* ---- ID Card Layout ---- */
.id-cards-container {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(var(--card-width), 1fr));
  gap: 15px;
  justify-content: center;
  margin-top: 20px;
}

.id-card {
  width: var(--card-width);
  height: var(--card-height);
  border-radius: 8px;
  overflow: hidden;
  background: #fff;
  box-shadow: var(--card-shadow);
  border: 1px solid #ccc;
  position: relative;
  display: flex;
  flex-direction: column;
  transition: transform 0.2s;
}
.id-card:hover { transform: scale(1.02); }

/* ---- Header stripe ---- */
.id-top {
  background: var(--bg-gradient);
  color: #fff;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 4px 8px;
  height: 28px;
  border-bottom: 2px solid var(--accent-color);
}
.id-top img {
  width: 22px; height: 22px;
}
.school-details {
  text-align: center;
  flex: 1;
  font-size: 0.55rem;
  line-height: 1.1;
}
.school-details div:first-child {
  font-weight: bold;
  font-size: 0.65rem;
}
.school-details div:last-child {
  font-size: 0.5rem;
  opacity: 0.9;
}

/* ---- Middle area ---- */
.id-middle {
  display: flex;
  padding: 6px;
  background: linear-gradient(to bottom right, #fdfdfd, #f2f6fa);
  height: calc(var(--card-height) - 30px);
}

/* left: photo + barcode */
.photo-barcode-wrapper {
  width: 60px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.photo-container {
  width: 52px; height: 60px;
  border-radius: 4px;
  overflow: hidden;
  border: 1px solid var(--secondary-color);
  background: #eaf6fb;
  margin-bottom: 4px;
}
.photo-container img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.barcode-container {
  background: #fff;
  width: 52px;
  height: 16px;
  border: 0.5px solid #ccc;
  border-radius: 2px;
}

/* right: student info */
.student-info {
  flex: 1;
  font-size: 0.62rem;
  padding-left: 6px;
  display: flex;
  flex-direction: column;
}
.id-title {
  background: var(--secondary-color);
  color: #fff;
  text-align: center;
  font-weight: 600;
  font-size: 0.7rem;
  padding: 2px;
  border-radius: 4px;
  margin-bottom: 4px;
  letter-spacing: 0.5px;
}
.info-grid {
  display: grid;
  grid-template-columns: auto 1fr;
  gap: 2px 5px;
}
.info-label {
  font-weight: 600;
  color: var(--primary-color);
}
.info-value {
  color: #111;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* Signature area */
.signature-area {
  margin-top: auto;
  border-top: 0.5px dotted var(--secondary-color);
  text-align: right;
  font-size: 0.55rem;
  padding-top: 2px;
  color: #333;
}

/* ---- Print view ---- */
@media print {
  @page { size: landscape; margin: 0.5cm; }
  body { background: #fff; padding: 0; }
  header, .form-container { display: none !important; }
  .id-cards-container {
    grid-template-columns: repeat(5, 1fr);
    grid-template-rows: repeat(2, 1fr);
    gap: 6px;
  }
  .id-card {
    box-shadow: none;
    border: 1px solid #000;
    page-break-inside: avoid;
  }
}
</style>
    </head>
    <body>
      <div class="print-container">
  `);
  
  // Clone each card for printing
  const cards = container.querySelectorAll('.id-card');
  cards.forEach(card => {
    const clone = card.cloneNode(true);
    printWindow.document.write(clone.outerHTML);
  });
  
  printWindow.document.write(`
      </div>
    </body>
    </html>
  `);
  
  printWindow.document.close();
  
  // Print after content loads
  printWindow.onload = function() {
    printWindow.print();
    printWindow.afterprint = function() {
      printWindow.close();
    };
  };
}

async function downloadPDF() {
  const container = document.getElementById('idCardsContainer');
  if (container.children.length === 0) {
    alert("Please generate ID cards first");
    return;
  }
  
  const pdf = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4'
  });
  
  const cards = container.querySelectorAll('.id-card');
  const cardWidth = 48; // mm
  const cardHeight = 30; // mm
  const gap = 5;
  let x = 10, y = 10;
  let count = 0;

  for (let i = 0; i < cards.length; i++) {
    const card = cards[i];
    const canvas = await html2canvas(card, { 
      scale: 3, 
      useCORS: true,
      backgroundColor: '#ffffff'
    });
    
    const imgData = canvas.toDataURL('image/png');
    pdf.addImage(imgData, 'PNG', x, y, cardWidth, cardHeight);

    count++;
    x += cardWidth + gap;
    
    if (count % 5 === 0) { 
      x = 10; 
      y += cardHeight + gap; 
    }
    
    if (count % 10 === 0 && count < cards.length) { 
      pdf.addPage(); 
      x = 10; 
      y = 10; 
    }
  }

  pdf.save(`student_cards_${new Date().toISOString().slice(0,10)}.pdf`);
}

function downloadImage() {
  const container = document.getElementById('idCardsContainer');
  if (container.children.length === 0) {
    alert("Please generate ID cards first");
    return;
  }
  
  html2canvas(container, { 
    scale: 2, 
    useCORS: true,
    backgroundColor: '#f0f4f8'
  }).then(canvas => {
    const link = document.createElement('a');
    link.href = canvas.toDataURL('image/png');
    link.download = `student_cards_${new Date().toISOString().slice(0,10)}.png`;
    link.click();
  });
}

// Add event listener for Enter key on select
document.getElementById('classSelect').addEventListener('keypress', function(e) {
  if (e.key === 'Enter') {
    loadCards();
  }
});

// Auto-load if URL has class_name parameter
window.onload = function() {
  const urlParams = new URLSearchParams(window.location.search);
  const className = urlParams.get('class_name');
  if (className) {
    document.getElementById('classSelect').value = className;
    setTimeout(() => loadCards(), 500);
  }
};
</script>
</body>
</html>