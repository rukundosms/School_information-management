
 <?php
            session_start(); // Start the session to access messages
            if (isset($_SESSION['error_message'])) {
                echo '<p class="error-message">' . htmlspecialchars($_SESSION['error_message']) . '</p>';
                unset($_SESSION['error_message']); // Clear the message after displaying
            }
            ?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Security-Policy" content="
    default-src 'self';
    script-src 'self' 'unsafe-inline';
    style-src 'self' 'unsafe-inline';
    img-src 'self' data:;
">
    <title>Login</title>
    <style>
        /* Base Styles */
        * {
            padding: 0;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            box-sizing: border-box;
        }

        body {
            background-color: #f0f8f0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 16px;
            line-height: 1.5;
        }

        .cont {
            background-color: white;
            border-radius: 12px;
            padding: 24px;
            width: 100%;
            max-width: 420px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #2c3e50;
            margin-bottom: 24px;
            text-align: center;
            font-size: 1.75rem;
            font-weight: 600;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #2c3e50;
            font-size: 0.95rem;
            font-weight: 500;
        }

        .required {
            color: #e74c3c;
            font-size: 0.8em;
            vertical-align: super;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px 16px;
            font-size: 1rem;
            border: 1px solid #ddd;
            border-radius: 8px;
            transition: border-color 0.3s;
            background-color: #f9f9f9;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: #3498db;
            background-color: #fff;
        }

        .checkbox-container {
            display: flex;
            align-items: center;
            margin: 16px 0;
        }

        #check {
            width: 18px;
            height: 18px;
            margin-right: 8px;
            accent-color: #3498db;
        }

        .checkbox-label {
            font-size: 0.9rem;
            color: #555;
            /* user-select:none; */
        }

        button {
            width: 100%;
            padding: 14px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-bottom: 20px;
        }

        button:hover {
            background-color: #2980b9;
        }

        .links {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 12px;
        }

        .link {
            color: #3498db;
            text-decoration: none;
            font-size: 0.9rem;
            transition: color 0.3s;
        }

        .link:hover {
            color: #2980b9;
            text-decoration: underline;
        }

        /* Responsive Adjustments */
        @media (max-width: 480px) {
            .cont {
                padding: 20px;
            }
            
            h1 {
                font-size: 1.5rem;
                margin-bottom: 20px;
            }
            
            input[type="text"],
            input[type="password"] {
                padding: 10px 14px;
            }
            
            button {
                padding: 12px;
            }
            
            .links {
                flex-direction: column;
                align-items: center;
                gap: 8px;
            }
        }

        @media (min-width: 768px) {
            .cont {
                padding: 32px;
            }
            
            h1 {
                font-size: 2rem;
            }
        }

        /* Animation */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .cont {
            animation: fadeIn 0.4s ease-out;
        }
        .error-message {
            color: #e74c3c;
            text-align: center;
            margin-bottom: 15px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <form action="login.php" method="POST">
        <div class="cont">
            <h1>Welcome! Please Login</h1>

            
            <div class="form-group">
                <label for="username">Username <span class="required">*</span></label>
                <input type="text" id="username" name="username" 
                        placeholder="Enter your username" 
                        autocomplete="username" 
                        required>
            </div>
            
            <div class="form-group">
                <label for="password">Password <span class="required">*</span></label>
                <input type="password" id="password" name="password_hash" 
                        placeholder="Enter your password" 
                        autocomplete="current-password" 
                        required>
            </div>
            
            <div class="checkbox-container">
                <input type="checkbox" id="check">
                <label for="check" class="checkbox-label">Show Password</label>
            </div>
            
            <button type="submit" name="login">Login</button>
            
            <div class="links">
                <a href="admin_creation.php" class="link">Create Account</a>
                <a href="sign.php" class="link">Teacher Login</a>
                <a href="#" class="link">Forgot Password?</a>
            </div>
        </div>
    </form>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Toggle password visibility
            const check = document.getElementById("check");
            const password = document.getElementById("password");
            
            if (check && password) {
                check.addEventListener("change", function() {
                    password.type = this.checked ? "text" : "password";
                });
            }
        
            // Add focus styles for inputs
            const inputs = document.querySelectorAll("input[type='text'], input[type='password']");
            
            inputs.forEach(input => {
                input.addEventListener("focus", function() {
                    this.style.borderColor = "#3498db";
                    this.style.borderWidth = "2px";
                });
                
                input.addEventListener("blur", function() {
                    this.style.borderColor = "#ddd";
                    this.style.borderWidth = "1px";
                });
            });
        });
    </script>
</body>
</html>