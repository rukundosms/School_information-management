<?php
// id_registration.php - Fixed Student ID Card Management

include('connection.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Ensure uploads directory exists
$upload_dir = "uploads/";
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

// Helper: escape text for HTML
function e($s) {
    return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
}

// -----------------------------
// Handle form submissions
// -----------------------------
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $reg_no        = trim($_POST['reg_no'] ?? '');
    $first_name    = trim($_POST['first_name'] ?? '');
    $last_name     = trim($_POST['last_name'] ?? '');
    $sex           = $_POST['sex'] ?? '';
    $level         = $_POST['level'] ?? '';
    $class         = trim($_POST['class'] ?? '');
    $academic_year = trim($_POST['academic_year'] ?? '');
    $school_name   = trim($_POST['school_name'] ?? '');
    $school_phone  = trim($_POST['school_phone'] ?? '');
    $school_email  = trim($_POST['school_email'] ?? '');

    if (empty($reg_no) || empty($first_name) || empty($last_name) || empty($level) || empty($class) || empty($academic_year) || empty($school_name)) {
        $error_message = "Please fill all required fields.";
    } else {
        // File upload
        $new_uploaded_path = null;
        if (isset($_FILES['student_photo']) && $_FILES['student_photo']['error'] == UPLOAD_ERR_OK) {
            $tmp  = $_FILES['student_photo']['tmp_name'];
            $size = $_FILES['student_photo']['size'];
            $mime = mime_content_type($tmp);
            $allowed = ['image/jpeg','image/png','image/gif'];
            if ($size > 4*1024*1024) {
                $error_message = "Photo too large (max 4MB).";
            } elseif (!in_array($mime, $allowed)) {
                $error_message = "Invalid photo type.";
            } else {
                $ext = pathinfo($_FILES['student_photo']['name'], PATHINFO_EXTENSION);
                $file_name = time().'_'.bin2hex(random_bytes(5)).'.'.$ext;
                $target_path = $upload_dir.$file_name;
                if (move_uploaded_file($tmp, $target_path)) {
                    $new_uploaded_path = $target_path;
                } else {
                    $error_message = "Failed to upload photo.";
                }
            }
        }

        // CREATE
        if (isset($_POST['create']) && !isset($error_message)) {
            $stmt = $conn->prepare("
                INSERT INTO id_card 
                (reg_no, first_name, last_name, sex, level, class, student_photo, academic_year, school_name, school_phone, school_email, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
            ");
            $stmt->bind_param("sssssssssss",
                $reg_no, $first_name, $last_name, $sex, $level, $class,
                $new_uploaded_path, $academic_year, $school_name, $school_phone, $school_email
            );
            if ($stmt->execute()) {
                $success_message = "Student record created successfully!";
            } else {
                $error_message = "Error creating record: ".$stmt->error;
                if ($new_uploaded_path && file_exists($new_uploaded_path)) unlink($new_uploaded_path);
            }
            $stmt->close();
        }

        // UPDATE
        if (isset($_POST['update']) && !isset($error_message)) {
            $student_id = intval($_POST['student_id']);
            $existing_photo = $_POST['existing_photo'] ?? '';

            if ($new_uploaded_path) {
                $stmt = $conn->prepare("
                    UPDATE id_card SET
                    reg_no=?, first_name=?, last_name=?, sex=?, level=?, class=?, student_photo=?, academic_year=?, school_name=?, school_phone=?, school_email=?, updated_at=NOW()
                    WHERE student_id=?
                ");
                $stmt->bind_param("sssssssssssi",
                    $reg_no, $first_name, $last_name, $sex, $level, $class,
                    $new_uploaded_path, $academic_year, $school_name, $school_phone, $school_email,
                    $student_id
                );
                if ($stmt->execute()) {
                    $success_message = "Student record updated successfully!";
                    if (!empty($existing_photo) && file_exists($existing_photo) && $existing_photo !== $new_uploaded_path) {
                        unlink($existing_photo);
                    }
                } else {
                    $error_message = "Error updating: ".$stmt->error;
                    if ($new_uploaded_path && file_exists($new_uploaded_path)) unlink($new_uploaded_path);
                }
                $stmt->close();
            } else {
                $stmt = $conn->prepare("
                    UPDATE id_card SET
                    reg_no=?, first_name=?, last_name=?, sex=?, level=?, class=?, academic_year=?, school_name=?, school_phone=?, school_email=?, updated_at=NOW()
                    WHERE student_id=?
                ");
                $stmt->bind_param("ssssssssssi",
                    $reg_no, $first_name, $last_name, $sex, $level, $class,
                    $academic_year, $school_name, $school_phone, $school_email,
                    $student_id
                );
                if ($stmt->execute()) {
                    $success_message = "Student record updated successfully!";
                } else {
                    $error_message = "Error updating: ".$stmt->error;
                }
                $stmt->close();
            }
        }
    }
}

// -----------------------------
// DELETE
// -----------------------------
if (isset($_GET['delete'])) {
    $student_id = intval($_GET['delete']);
    $stmt = $conn->prepare("SELECT student_photo FROM id_card WHERE student_id=?");
    $stmt->bind_param("i",$student_id);
    $stmt->execute();
    $stmt->bind_result($photoPath);
    $stmt->fetch();
    $stmt->close();

    $stmt = $conn->prepare("DELETE FROM id_card WHERE student_id=?");
    $stmt->bind_param("i",$student_id);
    if ($stmt->execute()) {
        if (!empty($photoPath) && file_exists($photoPath)) unlink($photoPath);
        $success_message = "Student deleted successfully!";
    } else {
        $error_message = "Error deleting: ".$stmt->error;
    }
    $stmt->close();
}

// -----------------------------
// FETCH
// -----------------------------
$students = $conn->query("SELECT * FROM id_card ORDER BY created_at DESC");

$edit_student = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $stmt = $conn->prepare("SELECT * FROM id_card WHERE student_id=?");
    $stmt->bind_param("i",$id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows>0) {
        $edit_student = $result->fetch_assoc();
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Student ID Manager</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<style>
.photo-preview {width:150px;height:180px;border:1px dashed #aaa;display:flex;align-items:center;justify-content:center;}
.student-thumb{width:50px;height:50px;object-fit:cover;}
</style>
</head>
<body class="bg-light">

<div class="container py-4">
    <h2 class="mb-4">Student Registration</h2>

    <?php if(isset($success_message)): ?>
        <div class="alert alert-success"><?=e($success_message)?></div>
    <?php endif; ?>
    <?php if(isset($error_message)): ?>
        <div class="alert alert-danger"><?=e($error_message)?></div>
    <?php endif; ?>

    <div class="row">
        <!-- FORM -->
        <div class="col-md-5">
            <form method="post" enctype="multipart/form-data">
                <?php if($edit_student): ?>
                    <input type="hidden" name="student_id" value="<?=e($edit_student['student_id'])?>">
                    <input type="hidden" name="existing_photo" value="<?=e($edit_student['student_photo'])?>">
                <?php endif; ?>

                <div class="mb-2">
                    <label>Reg No</label>
                    <input type="text" name="reg_no" class="form-control" required value="<?=e($edit_student['reg_no']??'')?>">
                </div>
                <div class="mb-2">
                    <label>First Name</label>
                    <input type="text" name="first_name" class="form-control" required value="<?=e($edit_student['first_name']??'')?>">
                </div>
                <div class="mb-2">
                    <label>Last Name</label>
                    <input type="text" name="last_name" class="form-control" required value="<?=e($edit_student['last_name']??'')?>">
                </div>
                <div class="mb-2">
                    <label>Gender</label>
                    <select name="sex" class="form-select">
                        <option value="">Select</option>
                        <option value="Male" <?=($edit_student && $edit_student['sex']=='Male')?'selected':''?>>Male</option>
                        <option value="Female" <?=($edit_student && $edit_student['sex']=='Female')?'selected':''?>>Female</option>
                    </select>
                </div>
                <div class="mb-2">
                    <label>Level</label>
                    <input type="text" name="level" class="form-control" required value="<?=e($edit_student['level']??'')?>">
                </div>
                <div class="mb-2">
                    <label>Class</label>
                    <input type="text" name="class" class="form-control" required value="<?=e($edit_student['class']??'')?>">
                </div>
                <div class="mb-2">
                    <label>Academic Year</label>
                    <input type="text" name="academic_year" class="form-control" required value="<?=e($edit_student['academic_year']??'')?>">
                </div>
                <div class="mb-2">
                    <label>School Name</label>
                    <input type="text" name="school_name" class="form-control" required value="<?=e($edit_student['school_name']??'')?>">
                </div>
                <div class="mb-2">
                    <label>School Phone</label>
                    <input type="text" name="school_phone" class="form-control" value="<?=e($edit_student['school_phone']??'')?>">
                </div>
                <div class="mb-2">
                    <label>School Email</label>
                    <input type="email" name="school_email" class="form-control" value="<?=e($edit_student['school_email']??'')?>">
                </div>
                <div class="mb-2">
                    <label>Photo</label>
                    <input type="file" name="student_photo" class="form-control">
                    <?php if($edit_student && $edit_student['student_photo']): ?>
                        <div class="photo-preview mt-2">
                            <img src="<?=e($edit_student['student_photo'])?>" style="max-width:100%;max-height:100%;">
                        </div>
                    <?php endif; ?>
                </div>
                <div class="mt-3">
                    <?php if($edit_student): ?>
                        <button type="submit" name="update" class="btn btn-primary">Update</button>
                        <a href="id_registration.php" class="btn btn-secondary">Cancel</a>
                    <?php else: ?>
                        <button type="submit" name="create" class="btn btn-success">Register</button>
                        <a href="import_id_info.php" class="btn btn-primary">import</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- LIST -->
        <div class="col-md-7">
            <table class="table table-bordered bg-white">
                <thead><tr><th>Photo</th><th>RegNo</th><th>Name</th><th>Gender</th><th>Class</th><th>Actions</th></tr></thead>
                <tbody>
                <?php if($students && $students->num_rows>0): while($r=$students->fetch_assoc()): ?>
                    <tr>
                        <td><?php if($r['student_photo']): ?><img src="<?=e($r['student_photo'])?>" class="student-thumb"><?php endif;?></td>
                        <td><?=e($r['reg_no'])?></td>
                        <td><?=e($r['first_name'].' '.$r['last_name'])?></td>
                        <td><?=e($r['sex'])?></td>
                        <td><?=e($r['class'])?></td>
                        <td>
                            <a href="?edit=<?=e($r['student_id'])?>" class="btn btn-sm btn-warning">Edit</a>
                            <a href="?delete=<?=e($r['student_id'])?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this record?')">Delete</a>
                            <a href="id_card_generator.php?student_id=<?=e($r['student_id'])?>" class="btn btn-sm btn-info">View ID</a>
                        </td>
                    </tr>
                <?php endwhile; else: ?>
                    <tr><td colspan="6" class="text-center">No records</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>

<?php $conn->close(); ?>
