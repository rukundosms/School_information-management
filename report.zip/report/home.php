<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("location:index.html"); 
    exit();
}

// Error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

include("connection.php");

// Check database connection
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Initialize all variables with default values
$online_teachers = [];
$current_academic_year = date('Y');
$total_classes = 0;
$total_students = 0;
$total_teachers = 0;
$total_assessments = 0;
$total_modules = 0;
$formative_assessments = 0;
$comprehensive_assessments = 0;
$completed_assessments = 0;
$pending_assessments = 0;
$completion_rate = 0;
$active_students = 0;
$promoted_students = 0;

// New detailed statistics arrays
$students_missed_assessments = [];
$teachers_pending_assessments = [];
$module_progress_data = [];
$class_progress_data = [];
$teacher_progress_data = [];
$recent_activities = [];
$modules_not_assessed = []; // NEW: Modules with no assessments
$modules_missing_formative = []; // NEW: Modules missing formative assessment
$modules_missing_comprehensive = []; // NEW: Modules missing comprehensive assessment

try {
    // 1. Get current academic year
    $year_query = mysqli_query($conn, "SELECT year FROM year LIMIT 1");
    if ($year_query && mysqli_num_rows($year_query) > 0) {
        $year_data = mysqli_fetch_assoc($year_query);
        $current_academic_year = $year_data['year'];
    }

    // 2. Basic counts - SIMPLE QUERIES
    $total_classes = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM class"))['count'] ?? 0;
    $total_students = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM student"))['count'] ?? 0;
    $total_teachers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM teacher"))['count'] ?? 0;
    $total_assessments = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM assessment"))['count'] ?? 0;
    $total_modules = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM module"))['count'] ?? 0;
    
    // 3. Assessment type breakdown - SIMPLE
    $formative_assessments = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM assessment WHERE AssName LIKE '%test%' OR AssName LIKE '%Test%' OR AssName LIKE '%formative%' OR AssName LIKE '%Formative%'"))['count'] ?? 0;
    $comprehensive_assessments = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM assessment WHERE AssName LIKE '%exam%' OR AssName LIKE '%Exam%' OR AssName LIKE '%final%' OR AssName LIKE '%Final%' OR AssName LIKE '%comprehensive%' OR AssName LIKE '%Comprehensive%'"))['count'] ?? 0;

    // 4. COMPLETED ASSESSMENTS - FIXED: Count modules that have marks
    $completed_result = mysqli_query($conn, "
        SELECT COUNT(DISTINCT m.moid) as count 
        FROM module m 
        WHERE EXISTS (
            SELECT 1 FROM marks mk 
            WHERE mk.mid = m.moid AND (mk.test > 0 OR mk.exam > 0)
        )
    ");
    $completed_assessments = $completed_result ? (mysqli_fetch_assoc($completed_result)['count'] ?? 0) : 0;
    
    $pending_assessments = max(0, $total_modules - $completed_assessments);
    $completion_rate = $total_modules > 0 ? round(($completed_assessments / $total_modules) * 100, 2) : 0;

    // 5. MODULES NOT ASSESSED - NEW FEATURE
    $modules_not_assessed_query = mysqli_query($conn, "
        SELECT 
            m.moid,
            m.mname,
            m.mcode,
            c.class_name,
            a.AssNo,
            a.AssName,
            CASE 
                WHEN a.AssName LIKE '%test%' OR a.AssName LIKE '%Test%' OR a.AssName LIKE '%formative%' OR a.AssName LIKE '%Formative%' THEN 'Formative'
                WHEN a.AssName LIKE '%exam%' OR a.AssName LIKE '%Exam%' OR a.AssName LIKE '%final%' OR a.AssName LIKE '%Final%' OR a.AssName LIKE '%comprehensive%' OR a.AssName LIKE '%Comprehensive%' THEN 'Comprehensive'
                ELSE 'Other'
            END as assessment_type,
            t.tid,
            t.tcode,
            t.fname as teacher_fname,
            t.lname as teacher_lname,
            (SELECT COUNT(DISTINCT s.sid) FROM student s WHERE s.class = c.cid AND s.status = 'active') as total_students,
            (SELECT COUNT(DISTINCT mk.sid) FROM marks mk WHERE mk.mid = m.moid AND mk.cid = c.cid AND (mk.test > 0 OR mk.exam > 0)) as assessed_students
        FROM module m
        JOIN class c ON m.class = c.cid
        JOIN assessment a ON m.moid = a.AssNo
        LEFT JOIN permission p ON p.mid = m.moid AND p.cid = c.cid
        LEFT JOIN teacher t ON p.tid = t.tid
        WHERE NOT EXISTS (
            SELECT 1 FROM marks mk 
            WHERE mk.mid = m.moid AND mk.cid = c.cid AND (mk.test > 0 OR mk.exam > 0)
        )
        AND EXISTS (SELECT 1 FROM student s WHERE s.class = c.cid AND s.status = 'active')
        ORDER BY c.class_name, m.mname
        LIMIT 50
    ");

    if ($modules_not_assessed_query) {
        while ($row = mysqli_fetch_assoc($modules_not_assessed_query)) {
            $modules_not_assessed[] = $row;
        }
    }

    // 6. MODULES MISSING FORMATIVE ASSESSMENT - NEW FEATURE
    $modules_missing_formative_query = mysqli_query($conn, "
        SELECT 
            m.moid,
            m.mname,
            m.mcode,
            c.class_name,
            t.tid,
            t.tcode,
            t.fname as teacher_fname,
            t.lname as teacher_lname,
            (SELECT COUNT(DISTINCT s.sid) FROM student s WHERE s.class = c.cid AND s.status = 'active') as total_students,
            (SELECT COUNT(DISTINCT mk.sid) FROM marks mk WHERE mk.mid = m.moid AND mk.cid = c.cid AND mk.test > 0) as students_with_test
        FROM module m
        JOIN class c ON m.class = c.cid
        LEFT JOIN permission p ON p.mid = m.moid AND p.cid = c.cid
        LEFT JOIN teacher t ON p.tid = t.tid
        WHERE EXISTS (
            SELECT 1 FROM assessment a 
            WHERE a.AssNo = m.moid AND 
            (a.AssName LIKE '%test%' OR a.AssName LIKE '%Test%' OR a.AssName LIKE '%formative%' OR a.AssName LIKE '%Formative%')
        )
        AND NOT EXISTS (
            SELECT 1 FROM marks mk 
            WHERE mk.mid = m.moid AND mk.cid = c.cid AND mk.test > 0
        )
        AND EXISTS (SELECT 1 FROM student s WHERE s.class = c.cid AND s.status = 'active')
        ORDER BY c.class_name, m.mname
        LIMIT 50
    ");

    if ($modules_missing_formative_query) {
        while ($row = mysqli_fetch_assoc($modules_missing_formative_query)) {
            $modules_missing_formative[] = $row;
        }
    }

    // 7. MODULES MISSING COMPREHENSIVE ASSESSMENT - NEW FEATURE
    $modules_missing_comprehensive_query = mysqli_query($conn, "
        SELECT 
            m.moid,
            m.mname,
            m.mcode,
            c.class_name,
            t.tid,
            t.tcode,
            t.fname as teacher_fname,
            t.lname as teacher_lname,
            (SELECT COUNT(DISTINCT s.sid) FROM student s WHERE s.class = c.cid AND s.status = 'active') as total_students,
            (SELECT COUNT(DISTINCT mk.sid) FROM marks mk WHERE mk.mid = m.moid AND mk.cid = c.cid AND mk.exam > 0) as students_with_exam
        FROM module m
        JOIN class c ON m.class = c.cid
        LEFT JOIN permission p ON p.mid = m.moid AND p.cid = c.cid
        LEFT JOIN teacher t ON p.tid = t.tid
        WHERE EXISTS (
            SELECT 1 FROM assessment a 
            WHERE a.AssNo = m.moid AND 
            (a.AssName LIKE '%exam%' OR a.AssName LIKE '%Exam%' OR a.AssName LIKE '%final%' OR a.AssName LIKE '%Final%' OR a.AssName LIKE '%comprehensive%' OR a.AssName LIKE '%Comprehensive%')
        )
        AND NOT EXISTS (
            SELECT 1 FROM marks mk 
            WHERE mk.mid = m.moid AND mk.cid = c.cid AND mk.exam > 0
        )
        AND EXISTS (SELECT 1 FROM student s WHERE s.class = c.cid AND s.status = 'active')
        ORDER BY c.class_name, m.mname
        LIMIT 50
    ");

    if ($modules_missing_comprehensive_query) {
        while ($row = mysqli_fetch_assoc($modules_missing_comprehensive_query)) {
            $modules_missing_comprehensive[] = $row;
        }
    }

    // 8. STUDENTS WITH MISSED ASSESSMENTS - SIMPLIFIED
    $students_missed_query = mysqli_query($conn, "
        SELECT 
            s.sid,
            s.firstname,
            s.lastname,
            s.reg,
            c.class_name,
            m.moid,
            m.mname,
            m.mcode,
            a.AssNo,
            a.AssName,
            CASE 
                WHEN a.AssName LIKE '%test%' OR a.AssName LIKE '%Test%' OR a.AssName LIKE '%formative%' OR a.AssName LIKE '%Formative%' THEN 'Formative'
                WHEN a.AssName LIKE '%exam%' OR a.AssName LIKE '%Exam%' OR a.AssName LIKE '%final%' OR a.AssName LIKE '%Final%' OR a.AssName LIKE '%comprehensive%' OR a.AssName LIKE '%Comprehensive%' THEN 'Comprehensive'
                ELSE 'Other'
            END as assessment_type,
            t.tid,
            t.tcode,
            t.fname as teacher_fname,
            t.lname as teacher_lname
        FROM student s
        JOIN class c ON s.class = c.cid
        JOIN module m ON m.class = c.cid
        JOIN assessment a ON a.AssNo = m.moid
        LEFT JOIN permission p ON p.mid = m.moid AND p.cid = c.cid
        LEFT JOIN teacher t ON p.tid = t.tid
        WHERE NOT EXISTS (
            SELECT 1 FROM marks mk 
            WHERE mk.sid = s.sid AND mk.mid = m.moid AND (mk.test > 0 OR mk.exam > 0)
        )
        AND s.status = 'active'
        AND t.tid IS NOT NULL
        ORDER BY c.class_name, s.firstname, m.mname
        LIMIT 50
    ");

    if ($students_missed_query) {
        while ($row = mysqli_fetch_assoc($students_missed_query)) {
            $students_missed_assessments[] = $row;
        }
    }

    // 9. TEACHERS WITH PENDING ASSESSMENTS - SIMPLIFIED
    $teachers_pending_query = mysqli_query($conn, "
        SELECT DISTINCT
            t.tid,
            t.tcode,
            t.fname,
            t.lname,
            c.cid,
            c.class_name,
            m.moid,
            m.mname,
            m.mcode,
            a.AssNo,
            a.AssName,
            CASE 
                WHEN a.AssName LIKE '%test%' OR a.AssName LIKE '%Test%' OR a.AssName LIKE '%formative%' OR a.AssName LIKE '%Formative%' THEN 'Formative'
                WHEN a.AssName LIKE '%exam%' OR a.AssName LIKE '%Exam%' OR a.AssName LIKE '%final%' OR a.AssName LIKE '%Final%' OR a.AssName LIKE '%comprehensive%' OR a.AssName LIKE '%Comprehensive%' THEN 'Comprehensive'
                ELSE 'Other'
            END as assessment_type
        FROM teacher t
        JOIN permission p ON t.tid = p.tid
        JOIN class c ON p.cid = c.cid
        JOIN module m ON p.mid = m.moid
        JOIN assessment a ON m.moid = a.AssNo
        WHERE NOT EXISTS (
            SELECT 1 FROM marks mk 
            WHERE mk.tid = t.tid AND mk.mid = m.moid AND mk.cid = c.cid AND (mk.test > 0 OR mk.exam > 0)
        )
        ORDER BY t.fname, c.class_name, m.mname
        LIMIT 50
    ");

    if ($teachers_pending_query) {
        while ($row = mysqli_fetch_assoc($teachers_pending_query)) {
            $teachers_pending_assessments[] = $row;
        }
    }

    // 10. MODULE PROGRESS - SIMPLIFIED
    $module_progress_query = mysqli_query($conn, "
        SELECT 
            m.moid,
            m.mname,
            m.mcode,
            c.class_name,
            a.AssNo,
            a.AssName,
            CASE 
                WHEN a.AssName LIKE '%test%' OR a.AssName LIKE '%Test%' OR a.AssName LIKE '%formative%' OR a.AssName LIKE '%Formative%' THEN 'Formative'
                WHEN a.AssName LIKE '%exam%' OR a.AssName LIKE '%Exam%' OR a.AssName LIKE '%final%' OR a.AssName LIKE '%Final%' OR a.AssName LIKE '%comprehensive%' OR a.AssName LIKE '%Comprehensive%' THEN 'Comprehensive'
                ELSE 'Other'
            END as assessment_type,
            (SELECT COUNT(DISTINCT s.sid) FROM student s WHERE s.class = c.cid AND s.status = 'active') as total_students,
            (SELECT COUNT(DISTINCT mk.sid) FROM marks mk WHERE mk.mid = m.moid AND mk.cid = c.cid AND (mk.test > 0 OR mk.exam > 0)) as assessed_students,
            COALESCE((SELECT AVG(mk.test) FROM marks mk WHERE mk.mid = m.moid AND mk.cid = c.cid AND mk.test > 0), 0) as avg_test_score,
            COALESCE((SELECT AVG(mk.exam) FROM marks mk WHERE mk.mid = m.moid AND mk.cid = c.cid AND mk.exam > 0), 0) as avg_exam_score,
            (SELECT t.tcode FROM permission p2 JOIN teacher t ON p2.tid = t.tid WHERE p2.mid = m.moid AND p2.cid = c.cid LIMIT 1) as responsible_teacher
        FROM module m
        JOIN class c ON m.class = c.cid
        JOIN assessment a ON m.moid = a.AssNo
        WHERE EXISTS (SELECT 1 FROM student s WHERE s.class = c.cid AND s.status = 'active')
        ORDER BY m.mname, c.class_name
        LIMIT 20
    ");

    if ($module_progress_query) {
        while ($row = mysqli_fetch_assoc($module_progress_query)) {
            $progress_percentage = $row['total_students'] > 0 ? round(($row['assessed_students'] / $row['total_students']) * 100, 2) : 0;
            $module_progress_data[] = array_merge($row, ['progress_percentage' => $progress_percentage]);
        }
    }

    // 11. RECENT ACTIVITIES - SIMPLIFIED
    $recent_marks_query = mysqli_query($conn, "
        SELECT 
            'assessment' as activity_type,
            CONCAT('Marks entered for ', m.mname, ' - ', 
                   CASE 
                       WHEN a.AssName LIKE '%test%' OR a.AssName LIKE '%Test%' OR a.AssName LIKE '%formative%' OR a.AssName LIKE '%Formative%' THEN 'Formative'
                       WHEN a.AssName LIKE '%exam%' OR a.AssName LIKE '%Exam%' OR a.AssName LIKE '%final%' OR a.AssName LIKE '%Final%' OR a.AssName LIKE '%comprehensive%' OR a.AssName LIKE '%Comprehensive%' THEN 'Comprehensive'
                       ELSE 'Other'
                   END) as description,
            mk.date as activity_date,
            t.tcode as processed_by,
            c.class_name
        FROM marks mk
        JOIN module m ON mk.mid = m.moid
        JOIN assessment a ON m.moid = a.AssNo
        JOIN teacher t ON mk.tid = t.tid
        JOIN class c ON mk.cid = c.cid
        WHERE mk.test > 0 OR mk.exam > 0
        ORDER BY mk.date DESC 
        LIMIT 10
    ");

    if ($recent_marks_query) {
        while ($row = mysqli_fetch_assoc($recent_marks_query)) {
            $recent_activities[] = $row;
        }
    }

    // If no recent marks, show sample data
    if (empty($recent_activities)) {
        $recent_activities[] = [
            'activity_type' => 'info',
            'description' => 'System ready for assessment data',
            'activity_date' => date('Y-m-d H:i:s'),
            'processed_by' => 'System',
            'class_name' => 'All Classes'
        ];
    }

} catch (Exception $e) {
    error_log("Dashboard error: " . $e->getMessage());
}

// Fetch school info
$school_name = 'School Management System';
$school_check = mysqli_query($conn, "SHOW TABLES LIKE 'school'");
if ($school_check && mysqli_num_rows($school_check) > 0) {
    $school_query = mysqli_query($conn, "SELECT * FROM school LIMIT 1");
    if ($school_query && mysqli_num_rows($school_query) > 0) {
        $school = mysqli_fetch_array($school_query);
        $school_name = htmlspecialchars($school['school_name'] ?? 'School Management System');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bulletin - Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* CSS Variables */
        :root {
            --primary-color: #3498db;
            --secondary-color: #013220;
            --success-color: #27ae60;
            --warning-color: #f39c12;
            --danger-color: #e74c3c;
            --info-color: #17a2b8;
            --light-color: #ecf0f1;
            --dark-color: #2c3e50;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --radius: 8px;
        }

        /* Reset and Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fa;
            color: #333;
            line-height: 1.6;
            overflow: hidden; /* Prevent body scroll */
        }

        /* Layout */
        .cont {
            display: flex;
            flex-direction: column;
            height: 100vh; /* Full viewport height */
        }

        .top {
            background-color: var(--secondary-color);
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--shadow);
            z-index: 1002;
            flex-shrink: 0; /* Prevent shrinking */
        }

        .top .s {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .top img {
            height: 40px;
            border-radius: 50%;
        }

        .top h1 {
            font-size: 1.5rem;
            font-weight: 600;
        }

        .user h1 {
            font-size: 1.2rem;
            font-weight: 500;
        }

        .center {
            display: flex;
            flex: 1;
            min-height: 0; /* Important for flex children to respect overflow */
        }

        /* Sidebar */
        .left {
            width: 250px;
            background-color: var(--secondary-color);
            color: white;
            padding: 20px 0;
            transition: transform 0.3s ease;
            overflow-y: auto; /* Independent scrolling */
            z-index: 1001;
            flex-shrink: 0; /* Prevent shrinking */
        }

        .left h1 {
            padding: 0 20px 15px;
            font-size: 1.3rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            margin-bottom: 15px;
            position: sticky;
            top: 0;
            background-color: var(--secondary-color);
            z-index: 1;
        }

        .left nav {
            display: flex;
            flex-direction: column;
        }

        .left nav a {
            color: white;
            text-decoration: none;
            padding: 12px 20px;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 10px;
            border-radius: 4px;
            margin: 2px 10px;
        }

        .left nav a:hover, .left nav a.active {
            background-color: rgba(255, 255, 255, 0.2);
            padding-left: 25px;
        }

        .menu-toggle {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 1.2rem;
            cursor: pointer;
        }

        /* Dashboard Content */
        .dashboard-content {
            flex: 1;
            padding: 0;
            overflow-y: auto; /* Independent scrolling */
            background-color: #f5f7fa;
            min-height: 0; /* Important for flex children to respect overflow */
        }

        .dashboard-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
            min-height: min-content; /* Allow container to grow with content */
        }

        /* Iframe Container */
        .iframe-container {
            width: 100%;
            height: 100%;
            background: white;
            border: none;
            display: none;
        }

        .iframe-container.active {
            display: block;
        }

        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid #e0e0e0;
        }

        .dashboard-header h1 {
            color: var(--dark-color);
            font-size: 1.8rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .academic-year {
            background-color: var(--primary-color);
            color: white;
            padding: 8px 15px;
            border-radius: var(--radius);
            font-weight: 600;
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: var(--radius);
            padding: 20px;
            box-shadow: var(--shadow);
            text-align: center;
            border-top: 4px solid;
            transition: transform 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-card.success { border-top-color: var(--success-color); }
        .stat-card.info { border-top-color: var(--info-color); }
        .stat-card.warning { border-top-color: var(--warning-color); }
        .stat-card.danger { border-top-color: var(--danger-color); }

        .stat-icon {
            font-size: 2rem;
            margin-bottom: 10px;
        }

        .stat-card.success .stat-icon { color: var(--success-color); }
        .stat-card.info .stat-icon { color: var(--info-color); }
        .stat-card.warning .stat-icon { color: var(--warning-color); }
        .stat-card.danger .stat-icon { color: var(--danger-color); }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .stat-label {
            color: #666;
            font-size: 0.9rem;
        }

        /* Sections */
        .section {
            background: white;
            border-radius: var(--radius);
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: var(--shadow);
        }

        .section h3 {
            margin-bottom: 20px;
            color: var(--dark-color);
            font-size: 1.3rem;
            display: flex;
            align-items: center;
            gap: 10px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }

        /* Completion Rate */
        .completion-rate {
            font-size: 3rem;
            font-weight: 700;
            text-align: center;
            color: var(--success-color);
            margin: 20px 0 5px;
        }

        .rate-label {
            text-align: center;
            color: #666;
            margin-bottom: 25px;
        }

        /* Assessment Types */
        .assessment-types {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }

        .type-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 15px;
            border-radius: var(--radius);
            background-color: #f8f9fa;
            text-align: center;
        }

        .type-item i {
            font-size: 1.5rem;
            margin-bottom: 10px;
        }

        .type-item.info i { color: var(--info-color); }
        .type-item.success i { color: var(--success-color); }
        .type-item.warning i { color: var(--warning-color); }
        .type-item.danger i { color: var(--danger-color); }

        .type-value {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .type-label {
            color: #666;
            font-size: 0.9rem;
        }

        /* Assessment Breakdown */
        .assessment-breakdown {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .breakdown-card {
            background: white;
            border-radius: var(--radius);
            padding: 20px;
            box-shadow: var(--shadow);
            border-top: 4px solid var(--danger-color);
        }

        .breakdown-card.warning { border-top-color: var(--warning-color); }
        .breakdown-card.info { border-top-color: var(--info-color); }

        .breakdown-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .breakdown-title {
            font-weight: 600;
            color: var(--dark-color);
            font-size: 1.1rem;
        }

        .breakdown-count {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--danger-color);
        }

        .breakdown-count.warning { color: var(--warning-color); }
        .breakdown-count.info { color: var(--info-color); }

        .breakdown-list {
            max-height: 200px;
            overflow-y: auto;
        }

        .breakdown-item {
            padding: 8px 0;
            border-bottom: 1px solid #e9ecef;
            font-size: 0.85rem;
        }

        .breakdown-item:last-child {
            border-bottom: none;
        }

        .module-name {
            font-weight: 600;
            color: var(--dark-color);
        }

        .module-details {
            font-size: 0.75rem;
            color: #6c757d;
            margin-top: 2px;
        }

        /* Data Lists */
        .data-list {
            list-style: none;
        }

        .data-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid #eee;
            transition: background-color 0.2s;
        }

        .data-item:hover {
            background-color: #f8f9fa;
        }

        .item-info {
            flex: 1;
        }

        .item-main {
            font-weight: 600;
            margin-bottom: 5px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .item-sub {
            color: #666;
            font-size: 0.85rem;
        }

        .item-stats {
            display: flex;
            gap: 10px;
        }

        /* Detailed Items */
        .detailed-item {
            border-radius: var(--radius);
            padding: 20px;
            margin-bottom: 15px;
            border-left: 4px solid;
        }

        .detailed-item.danger { border-left-color: var(--danger-color); background-color: #fef2f2; }
        .detailed-item.warning { border-left-color: var(--warning-color); background-color: #fff8e1; }

        .item-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }

        .item-title {
            font-weight: 600;
            font-size: 1.1rem;
            margin-bottom: 5px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .item-subtitle {
            color: #666;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .item-details {
            display: grid;
            grid-template-columns: auto 1fr;
            gap: 10px 15px;
            font-size: 0.9rem;
        }

        .detail-label {
            font-weight: 600;
            color: #666;
        }

        /* Progress Bars */
        .progress-container {
            margin-top: 10px;
        }

        .progress-label {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
            font-size: 0.85rem;
        }

        .progress-bar {
            height: 8px;
            background-color: #e9ecef;
            border-radius: 4px;
            overflow: hidden;
        }

        .progress-fill {
            height: 100%;
            border-radius: 4px;
            transition: width 0.5s ease;
        }

        .progress-fill.success { background-color: var(--success-color); }
        .progress-fill.warning { background-color: var(--warning-color); }
        .progress-fill.danger { background-color: var(--danger-color); }

        /* Badges */
        .badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .badge.success { background-color: #d4edda; color: #155724; }
        .badge.info { background-color: #d1ecf1; color: #0c5460; }
        .badge.warning { background-color: #fff3cd; color: #856404; }
        .badge.danger { background-color: #f8d7da; color: #721c24; }

        .assessment-badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 0.7rem;
            font-weight: 600;
        }

        .assessment-badge.formative { background-color: #d1ecf1; color: #0c5460; }
        .assessment-badge.comprehensive { background-color: #d4edda; color: #155724; }
        .assessment-badge.other { background-color: #e2e3e5; color: #383d41; }

        /* Empty States */
        .empty-state {
            text-align: center;
            padding: 30px;
            color: #666;
            font-style: italic;
        }

        /* Debug Info */
        .debug-info {
            background-color: #f8f9fa;
            border-left: 4px solid var(--info-color);
            padding: 10px 15px;
            margin-bottom: 20px;
            font-size: 0.85rem;
            color: #666;
        }

        /* Responsive Design */
        @media (max-width: 992px) {
            .assessment-breakdown {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .center {
                flex-direction: column;
            }

            .left {
                width: 100%;
                position: fixed;
                top: 70px;
                left: 0;
                height: calc(100vh - 70px);
                z-index: 1000;
                transform: translateX(-100%);
            }

            .left.active {
                transform: translateX(0);
            }

            .menu-toggle {
                display: block;
            }

            .top {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                z-index: 1001;
            }

            .dashboard-content {
                margin-top: 70px;
                height: calc(100vh - 70px);
            }

            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .assessment-types {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 576px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }

            .assessment-types {
                grid-template-columns: 1fr;
            }

            .dashboard-header {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }

            .item-header {
                flex-direction: column;
                gap: 10px;
            }

            .item-stats {
                flex-wrap: wrap;
            }
        }

        /* Custom scrollbar for sidebar */
        .left::-webkit-scrollbar {
            width: 6px;
        }

        .left::-webkit-scrollbar-track {
            background: rgba(255, 255, 255, 0.1);
        }

        .left::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.3);
            border-radius: 3px;
        }

        .left::-webkit-scrollbar-thumb:hover {
            background: rgba(255, 255, 255, 0.5);
        }

        /* Custom scrollbar for dashboard */
        .dashboard-content::-webkit-scrollbar {
            width: 8px;
        }

        .dashboard-content::-webkit-scrollbar-track {
            background: #f1f1f1;
        }

        .dashboard-content::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 4px;
        }

        .dashboard-content::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }
    </style>
</head>
<body>
    <div class="cont">
        <div class="top">
            <div class="s">
                <button class="menu-toggle" id="menuToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <img src="images/logo.jpg" alt="School Logo">
                <h1><?php echo $school_name; ?></h1>
            </div>
            <div class="user">
                <h1><?php echo htmlspecialchars($_SESSION['username'] ?? 'User') ?> - Dashboard</h1>
            </div>
        </div>
        <div class="center">
            <div class="left" id="sidebar">
                <h1>Navigation Menus</h1>
                <nav>
                    <a href="teacher.php" data-target="teacher"><i class="fas fa-chalkboard-teacher"></i> Teachers</a>
                    <a href="student_class.php" data-target="students"><i class="fas fa-users"></i> Students</a>
                    <a href="#" data-target="trades"><i class="fas fa-tools"></i> Trades</a>
                    <a href="class.php" data-target="classes"><i class="fas fa-school"></i> Classes</a>
                    <a href="module.php" data-target="modules"><i class="fas fa-book"></i> Modules</a>
                    <a href="assessment.php" data-target="assessment"><i class="fas fa-clipboard-check"></i> Assessment</a>
                    <a href="grant.php" data-target="grant"><i class="fas fa-key"></i> Grant</a>
                    <a href="revok.php" data-target="revoke"><i class="fas fa-ban"></i> Revoke</a>
                    <a href="year.php" data-target="year"><i class="fas fa-calendar-alt"></i> Academic Year</a>
                    <a href="rep.php" data-target="report"><i class="fas fa-file-alt"></i> Report</a>
                    <a href="proclamation_year.php" data-target="ranking"><i class="fas fa-trophy"></i> Ranking</a>
                    <a href="school.php" data-target="school"><i class="fas fa-university"></i> School</a>
                    <a href="blue.php" data-target="profile"><i class="fas fa-user"></i> Progression</a>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </nav>
            </div>
            
            <div class="dashboard-content">
                <!-- Dashboard Content (default view) -->
                <div class="dashboard-container" id="dashboardView">
                    <!-- Debug Information -->
                    <div class="debug-info">
                        <strong>Database Statistics:</strong> 
                        Classes: <?php echo $total_classes; ?> | 
                        Students: <?php echo $total_students; ?> | 
                        Teachers: <?php echo $total_teachers; ?> | 
                        Assessments: <?php echo $total_assessments; ?> | 
                        Modules: <?php echo $total_modules; ?> | 
                        Completed Modules: <?php echo $completed_assessments; ?> |
                        Formative: <?php echo $formative_assessments; ?> |
                        Comprehensive: <?php echo $comprehensive_assessments; ?>
                    </div>

                    <div class="dashboard-header">
                        <h1><i class="fas fa-tachometer-alt"></i> Comprehensive Assessment Dashboard</h1>
                        <div class="academic-year">Academic Year: <?php echo $current_academic_year; ?></div>
                    </div>

                    <!-- Main Statistics -->
                    <div class="stats-grid">
                        <div class="stat-card success">
                            <i class="fas fa-school stat-icon"></i>
                            <div class="stat-value"><?php echo $total_classes; ?></div>
                            <div class="stat-label">Total Classes</div>
                        </div>

                        <div class="stat-card info">
                            <i class="fas fa-users stat-icon"></i>
                            <div class="stat-value"><?php echo $total_students; ?></div>
                            <div class="stat-label">Total Students</div>
                        </div>

                        <div class="stat-card warning">
                            <i class="fas fa-chalkboard-teacher stat-icon"></i>
                            <div class="stat-value"><?php echo $total_teachers; ?></div>
                            <div class="stat-label">Total Teachers</div>
                        </div>

                        <div class="stat-card danger">
                            <i class="fas fa-book stat-icon"></i>
                            <div class="stat-value"><?php echo $total_modules; ?></div>
                            <div class="stat-label">Total Modules</div>
                        </div>
                    </div>

                    <!-- Assessment Overview -->
                    <div class="section">
                        <h3><i class="fas fa-chart-pie"></i> Assessment Overview</h3>
                        <div class="completion-rate"><?php echo $completion_rate; ?>%</div>
                        <div class="rate-label">Module Assessment Completion Rate</div>
                        
                        <div class="assessment-types">
                            <div class="type-item info">
                                <i class="fas fa-edit"></i>
                                <div class="type-value"><?php echo $formative_assessments; ?></div>
                                <div class="type-label">Formative Assessments</div>
                            </div>
                            <div class="type-item success">
                                <i class="fas fa-file-alt"></i>
                                <div class="type-value"><?php echo $comprehensive_assessments; ?></div>
                                <div class="type-label">Comprehensive Assessments</div>
                            </div>
                            <div class="type-item warning">
                                <i class="fas fa-check-circle"></i>
                                <div class="type-value"><?php echo $completed_assessments; ?></div>
                                <div class="type-label">Assessed Modules</div>
                            </div>
                            <div class="type-item danger">
                                <i class="fas fa-clock"></i>
                                <div class="type-value"><?php echo $pending_assessments; ?></div>
                                <div class="type-label">Pending Modules</div>
                            </div>
                        </div>
                    </div>

                    <!-- NEW: Assessment Breakdown Section -->
                    <div class="section">
                        <h3><i class="fas fa-exclamation-circle"></i> Assessment Gap Analysis</h3>
                        <div class="assessment-breakdown">
                            <!-- Modules Not Assessed -->
                            <div class="breakdown-card">
                                <div class="breakdown-header">
                                    <div class="breakdown-title">Modules Not Assessed</div>
                                    <div class="breakdown-count"><?php echo count($modules_not_assessed); ?></div>
                                </div>
                                <div class="breakdown-list">
                                    <?php if (!empty($modules_not_assessed)): ?>
                                        <?php foreach ($modules_not_assessed as $module): ?>
                                            <div class="breakdown-item">
                                                <div class="module-name"><?php echo htmlspecialchars($module['mname']); ?></div>
                                                <div class="module-details">
                                                    <?php echo htmlspecialchars($module['class_name']); ?> • 
                                                    <?php echo htmlspecialchars($module['assessment_type']); ?> •
                                                    Teacher: <?php echo htmlspecialchars($module['teacher_fname'] . ' ' . $module['teacher_lname']); ?>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <div class="empty-state" style="padding: 10px; font-size: 0.8rem;">All modules have assessments</div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Modules Missing Formative Assessment -->
                            <div class="breakdown-card warning">
                                <div class="breakdown-header">
                                    <div class="breakdown-title">Missing Formative Assessments</div>
                                    <div class="breakdown-count warning"><?php echo count($modules_missing_formative); ?></div>
                                </div>
                                <div class="breakdown-list">
                                    <?php if (!empty($modules_missing_formative)): ?>
                                        <?php foreach ($modules_missing_formative as $module): ?>
                                            <div class="breakdown-item">
                                                <div class="module-name"><?php echo htmlspecialchars($module['mname']); ?></div>
                                                <div class="module-details">
                                                    <?php echo htmlspecialchars($module['class_name']); ?> • 
                                                    <?php echo $module['students_with_test']; ?>/<?php echo $module['total_students']; ?> students •
                                                    Teacher: <?php echo htmlspecialchars($module['teacher_fname'] . ' ' . $module['teacher_lname']); ?>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <div class="empty-state" style="padding: 10px; font-size: 0.8rem;">All formative assessments completed</div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Modules Missing Comprehensive Assessment -->
                            <div class="breakdown-card info">
                                <div class="breakdown-header">
                                    <div class="breakdown-title">Missing Comprehensive Assessments</div>
                                    <div class="breakdown-count info"><?php echo count($modules_missing_comprehensive); ?></div>
                                </div>
                                <div class="breakdown-list">
                                    <?php if (!empty($modules_missing_comprehensive)): ?>
                                        <?php foreach ($modules_missing_comprehensive as $module): ?>
                                            <div class="breakdown-item">
                                                <div class="module-name"><?php echo htmlspecialchars($module['mname']); ?></div>
                                                <div class="module-details">
                                                    <?php echo htmlspecialchars($module['class_name']); ?> • 
                                                    <?php echo $module['students_with_exam']; ?>/<?php echo $module['total_students']; ?> students •
                                                    Teacher: <?php echo htmlspecialchars($module['teacher_fname'] . ' ' . $module['teacher_lname']); ?>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <div class="empty-state" style="padding: 10px; font-size: 0.8rem;">All comprehensive assessments completed</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Students with Missed Assessments -->
                    <div class="section">
                        <h3><i class="fas fa-user-times"></i> Students with Missed Assessments</h3>
                        <?php if (!empty($students_missed_assessments)): ?>
                            <div class="data-list">
                                <?php foreach ($students_missed_assessments as $missed): ?>
                                    <div class="detailed-item danger">
                                        <div class="item-header">
                                            <div>
                                                <div class="item-title">
                                                    <?php echo htmlspecialchars($missed['firstname'] . ' ' . $missed['lastname']); ?>
                                                    <span class="badge danger"><?php echo htmlspecialchars($missed['reg']); ?></span>
                                                </div>
                                                <div class="item-subtitle">
                                                    Class: <?php echo htmlspecialchars($missed['class_name']); ?>
                                                    • Module: <?php echo htmlspecialchars($missed['mname']); ?>
                                                    <span class="assessment-badge <?php echo strtolower($missed['assessment_type']); ?>">
                                                        <?php echo htmlspecialchars($missed['assessment_type']); ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item-details">
                                            <div class="detail-label">Assessment:</div>
                                            <div><?php echo htmlspecialchars($missed['AssName']); ?></div>
                                            
                                            <div class="detail-label">Responsible Teacher:</div>
                                            <div>
                                                <?php echo htmlspecialchars($missed['teacher_fname'] . ' ' . $missed['teacher_lname']); ?>
                                                (<?php echo htmlspecialchars($missed['tcode']); ?>)
                                            </div>
                                            
                                            <div class="detail-label">Module Code:</div>
                                            <div><?php echo htmlspecialchars($missed['mcode']); ?></div>
                                            
                                            <div class="detail-label">Status:</div>
                                            <div class="badge danger">No Marks Entered</div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="empty-state">No students with missed assessments found</div>
                        <?php endif; ?>
                    </div>

                    <!-- Teachers with Pending Assessments -->
                    <div class="section">
                        <h3><i class="fas fa-user-clock"></i> Teachers with Pending Assessments</h3>
                        <?php if (!empty($teachers_pending_assessments)): ?>
                            <div class="data-list">
                                <?php foreach ($teachers_pending_assessments as $teacher): ?>
                                    <div class="detailed-item warning">
                                        <div class="item-header">
                                            <div>
                                                <div class="item-title">
                                                    <?php echo htmlspecialchars($teacher['fname'] . ' ' . $teacher['lname']); ?>
                                                    <span class="badge info"><?php echo htmlspecialchars($teacher['tcode']); ?></span>
                                                </div>
                                                <div class="item-subtitle">
                                                    Class: <?php echo htmlspecialchars($teacher['class_name']); ?>
                                                    • Module: <?php echo htmlspecialchars($teacher['mname']); ?>
                                                    <span class="assessment-badge <?php echo strtolower($teacher['assessment_type']); ?>">
                                                        <?php echo htmlspecialchars($teacher['assessment_type']); ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item-details">
                                            <div class="detail-label">Assessment:</div>
                                            <div><?php echo htmlspecialchars($teacher['AssName']); ?></div>
                                            
                                            <div class="detail-label">Module Code:</div>
                                            <div><?php echo htmlspecialchars($teacher['mcode']); ?></div>
                                            
                                            <div class="detail-label">Status:</div>
                                            <div class="badge warning">Pending Assessment</div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="empty-state">All teachers are up to date with assessments</div>
                        <?php endif; ?>
                    </div>

                    <!-- Module Progress -->
                    <div class="section">
                        <h3><i class="fas fa-tasks"></i> Module Progress Tracking</h3>
                        <?php if (!empty($module_progress_data)): ?>
                            <ul class="data-list">
                                <?php foreach ($module_progress_data as $module): ?>
                                    <li class="data-item">
                                        <div class="item-info">
                                            <div class="item-main">
                                                <?php echo htmlspecialchars($module['mname']); ?>
                                                <span class="assessment-badge <?php echo strtolower($module['assessment_type']); ?>">
                                                    <?php echo htmlspecialchars($module['assessment_type']); ?>
                                                </span>
                                            </div>
                                            <div class="item-sub">
                                                <?php echo htmlspecialchars($module['mcode']); ?> • 
                                                <?php echo htmlspecialchars($module['class_name']); ?> •
                                                Teacher: <?php echo htmlspecialchars($module['responsible_teacher'] ?? 'Not assigned'); ?>
                                            </div>
                                            <div class="progress-container">
                                                <div class="progress-label">
                                                    <span>Progress: <?php echo $module['progress_percentage']; ?>%</span>
                                                    <span><?php echo $module['assessed_students']; ?>/<?php echo $module['total_students']; ?> students</span>
                                                </div>
                                                <div class="progress-bar">
                                                    <div class="progress-fill <?php echo $module['progress_percentage'] >= 80 ? 'success' : ($module['progress_percentage'] >= 50 ? 'warning' : 'danger'); ?>" 
                                                         style="width: <?php echo $module['progress_percentage']; ?>%"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item-stats">
                                            <?php if ($module['avg_test_score'] > 0): ?>
                                                <div class="badge info">Test: <?php echo round($module['avg_test_score'], 1); ?></div>
                                            <?php endif; ?>
                                            <?php if ($module['avg_exam_score'] > 0): ?>
                                                <div class="badge success">Exam: <?php echo round($module['avg_exam_score'], 1); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php else: ?>
                            <div class="empty-state">No module progress data available</div>
                        <?php endif; ?>
                    </div>

                    <!-- Recent Activities -->
                    <div class="section">
                        <h3><i class="fas fa-history"></i> Recent Activities</h3>
                        <?php if (!empty($recent_activities)): ?>
                            <ul class="data-list">
                                <?php foreach ($recent_activities as $activity): ?>
                                    <li class="data-item">
                                        <div class="item-info">
                                            <div class="item-main"><?php echo htmlspecialchars($activity['description']); ?></div>
                                            <div class="item-sub">
                                                <span class="badge <?php echo $activity['activity_type'] === 'assessment' ? 'info' : 'success'; ?>">
                                                    <?php echo ucfirst($activity['activity_type']); ?>
                                                </span>
                                                • By: <?php echo htmlspecialchars($activity['processed_by']); ?>
                                                • Class: <?php echo htmlspecialchars($activity['class_name']); ?>
                                                • <?php echo date('M j, Y g:i A', strtotime($activity['activity_date'])); ?>
                                            </div>
                                        </div>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php else: ?>
                            <div class="empty-state">No recent activities</div>
                        <?php endif; ?>
                    </div>

                </div>

                <!-- Iframe for navigation content -->
                <iframe id="contentFrame" class="iframe-container" src="" frameborder="0"></iframe>
            </div>
        </div>
    </div>

    <script>
        // Toggle mobile menu
        document.getElementById('menuToggle').addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('active');
        });

        // Close menu when clicking outside on mobile
        document.addEventListener('click', function(event) {
            const sidebar = document.getElementById('sidebar');
            const menuToggle = document.getElementById('menuToggle');
            
            if (window.innerWidth <= 768 && 
                !sidebar.contains(event.target) && 
                !menuToggle.contains(event.target)) {
                sidebar.classList.remove('active');
            }
        });

        // Navigation links handling
        document.querySelectorAll('.left nav a').forEach(link => {
            if (link.getAttribute('href') !== 'logout.php') {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    // Remove active class from all links
                    document.querySelectorAll('.left nav a').forEach(a => {
                        a.classList.remove('active');
                    });
                    
                    // Add active class to clicked link
                    this.classList.add('active');
                    
                    const target = this.getAttribute('href');
                    
                    // Show iframe and hide dashboard
                    if (target && target !== '#') {
                        document.getElementById('contentFrame').src = target;
                        document.getElementById('contentFrame').classList.add('active');
                        document.getElementById('dashboardView').style.display = 'none';
                    }
                });
            }
        });

        // Auto-refresh dashboard every 2 minutes (only when on dashboard view)
        setInterval(function() {
            if (!document.getElementById('contentFrame').classList.contains('active')) {
                window.location.reload();
            }
        }, 120000);

        // Handle browser back button
        window.addEventListener('popstate', function(event) {
            // Show dashboard when back button is pressed
            document.getElementById('contentFrame').classList.remove('active');
            document.getElementById('dashboardView').style.display = 'block';
            
            // Remove active class from all navigation links
            document.querySelectorAll('.left nav a').forEach(a => {
                a.classList.remove('active');
            });
        });

        // Add back to dashboard functionality
        function showDashboard() {
            document.getElementById('contentFrame').classList.remove('active');
            document.getElementById('dashboardView').style.display = 'block';
            document.querySelectorAll('.left nav a').forEach(a => {
                a.classList.remove('active');
            });
        }
    </script>
</body>
</html>