<?php
include("connection.php");
session_start();

// Verify all required session variables
$required_sessions = [
    'tid' => 'Teacher ID',
    'cl' => 'Class ID', 
    'module' => 'Module ID',
    'name' => 'Module Name',
    'tearm' => 'Term',
    'year' => 'Year'
];

foreach ($required_sessions as $var => $desc) {
    if (!isset($_SESSION[$var])) {
        error_log("Missing session variable: $var ($desc)");
        header("Location: mymodules.php");
        exit();
    }
}

// Sanitize inputs
$class = mysqli_real_escape_string($conn, $_SESSION['cl']);
$me = mysqli_real_escape_string($conn, $_SESSION['tid']);
$module = mysqli_real_escape_string($conn, $_SESSION['module']);
$term = mysqli_real_escape_string($conn, $_SESSION['tearm']);
$year = mysqli_real_escape_string($conn, $_SESSION['year']);
$modules = htmlspecialchars($_SESSION['name']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marks - <?php echo htmlspecialchars($modules); ?></title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        
        body {
            background-color: #f5f5f5;
            padding: 15px;
        }
        
        .cont {
            max-width: 100%;
            overflow-x: auto;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin: 0 auto;
        }
        
        .term-header {
            background-color: #e1f5fe;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            text-align: center;
            font-weight: bold;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        
        caption {
            font-size: 1.2rem;
            font-weight: bold;
            margin-bottom: 10px;
            padding: 8px;
            color: #333;
        }
        
        th, td {
            padding: 12px 8px;
            text-align: left;
            border: 1px solid #ddd;
        }
        
        th {
            background-color: #4CAF50;
            color: white;
            font-weight: bold;
        }
        
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        
        .button-container {
            display: flex;
            gap: 10px;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 20px;
        }
        
        button {
            padding: 10px 20px;
            background-color: #4CAF50;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            color: white;
            transition: background-color 0.3s;
            min-width: 120px;
        }
        
        button:hover {
            background-color: #45a049;
        }
        
        .error-message {
            color: red;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid red;
            background-color: #ffeeee;
            border-radius: 4px;
        }
        
        .info-message {
            color: #31708f;
            background-color: #d9edf7;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #bce8f1;
            border-radius: 4px;
        }
        
        @media (max-width: 768px) {
            th, td {
                padding: 8px 5px;
                font-size: 14px;
            }
            
            caption {
                font-size: 1rem;
            }
            
            .cont {
                padding: 10px;
            }
        }
        
        @media (max-width: 480px) {
            th, td {
                padding: 6px 3px;
                font-size: 12px;
            }
            
            button {
                padding: 8px 15px;
                font-size: 14px;
                min-width: 100px;
            }
        }
        
        @media print {
            body {
                padding: 0;
                background-color: white;
            }
            
            .cont {
                box-shadow: none;
                padding: 0;
            }
            
            button {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="cont">
        <form action="" method="post">
            <div class="term-header">
                Term <?php echo htmlspecialchars($term); ?> - <?php echo htmlspecialchars($year); ?>
            </div>
            
            <?php
            // Check if marks exist for this term
            $check_query = "SELECT COUNT(*) as count FROM marks 
                          WHERE cid = '$class' 
                          AND tid = '$me' 
                          AND mid = '$module'
                          AND team = '$term'
                          AND year = '$year'";
            
            $check_result = mysqli_query($conn, $check_query);
            
            if (!$check_result) {
                echo '<div class="error-message">Database error</div>';
            } else {
                $row = mysqli_fetch_assoc($check_result);
                if ($row['count'] <= 0) {
                    echo '<div class="info-message">No marks found for this term</div>';
                }
            }
            
            // Get class/module info
            $sel = mysqli_query($conn, "SELECT class.level, module.mname 
                                     FROM class 
                                     JOIN module ON module.moid = '$module'
                                     WHERE class.cid = '$class'");
            ?>
            
            <table>
                <caption>
                    <?php
                    if ($sel && mysqli_num_rows($sel) > 0) {
                        $b = mysqli_fetch_array($sel);
                        echo htmlspecialchars($b['level']." ".$b['mname']);
                    } else {
                        echo "Class/Module Information";
                    }
                    ?>
                </caption>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Student Name</th>
                        <th>Test</th>
                        <th>Total</th>
                        <th>Exam</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
$select_query = "SELECT s.sid, s.firstname, s.lastname, 
                m.test, m.ttotal, m.exam, m.etotal 
                FROM student s
                JOIN marks m ON m.sid = s.sid 
                WHERE m.team = '$term'
                AND m.year = '$year'
                AND m.cid = '$class'
                AND m.tid = '$me'
                AND m.mid = '$module'
                ORDER BY s.firstname ASC";
                    
                    $select = mysqli_query($conn, $select_query);
                    
                    if (!$select) {
                        echo '<tr><td colspan="6" class="error-message">Error loading marks</td></tr>';
                    } elseif (mysqli_num_rows($select) > 0) {
                        $no = 0;
                        while ($a = mysqli_fetch_array($select)) {
                            $no++;
                            echo "<tr>
                                <td>".$no."</td>
                                <td>".htmlspecialchars($a['firstname']." ".$a['lastname'])."</td>
                                <td>".htmlspecialchars($a['test'])."</td>
                                <td>".htmlspecialchars($a['ttotal'])."</td>
                                <td>".htmlspecialchars($a['exam'])."</td>
                                <td>".htmlspecialchars($a['etotal'])."</td>
                            </tr>";
                        }
                    } else {
                        echo '<tr><td colspan="6">No student marks found</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
            
            <div class="button-container">
                <button type="submit" name="edit">Edit</button>
                <button type="button" onclick="window.print()">Print</button>
                <button type="button" onclick="window.location.href='mymodules.php'">Back</button>
            </div>
            
            <?php
            if (isset($_POST['edit'])) {
                $_SESSION['edit_class'] = $class;
                $_SESSION['edit_module'] = $module;
                $_SESSION['edit_term'] = $term;
                header("Location: edit.php");
                exit();
            }
            ?>
        </form>
    </div>
</body>
</html>