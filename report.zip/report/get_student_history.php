<?php
// get_student_history.php
require_once 'connection.php';

if (isset($_GET['student_id']) && is_numeric($_GET['student_id'])) {
    $studentId = (int)$_GET['student_id'];
    
    // Include the function directly here since we're not using promotion_manager.php anymore
    function getStudentHistory($conn, $studentId) {
        $history = [];
        
        $stmt = $conn->prepare("
            SELECT DISTINCT s.academic_year_id, ay.year_label 
            FROM students s
            JOIN academic_years ay ON s.academic_year_id = ay.academic_year_id
            WHERE s.student_id = ?
            ORDER BY ay.start_date DESC
        ");
        $stmt->bind_param("i", $studentId);
        $stmt->execute();
        $academicYears = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        foreach ($academicYears as $year) {
            $stmt = $conn->prepare("
                SELECT s.*, p.program_name, c.class_code, c.level,
                       (SELECT COUNT(*) FROM student_marks sm 
                        WHERE sm.student_id = s.student_id 
                        AND sm.academic_year_id = s.academic_year_id
                        AND sm.total_score >= 50) as passed_modules,
                       (SELECT COUNT(*) FROM student_marks sm 
                        WHERE sm.student_id = s.student_id 
                        AND sm.academic_year_id = s.academic_year_id) as total_modules
                FROM students s
                JOIN programs p ON s.program_id = p.program_id
                JOIN classes c ON s.current_class_id = c.class_id
                WHERE s.student_id = ? AND s.academic_year_id = ?
            ");
            $stmt->bind_param("ii", $studentId, $year['academic_year_id']);
            $stmt->execute();
            $studentData = $stmt->get_result()->fetch_assoc();
            
            if ($studentData) {
                $history[] = [
                    'academic_year' => $year['year_label'],
                    'data' => $studentData
                ];
            }
        }
        return $history;
    }

    $history = getStudentHistory($conn, $studentId);
    
    if (!empty($history)) {
        echo '<div class="student-history">';
        echo '<h4>Academic History for Student ID: ' . $studentId . '</h4>';
        
        foreach ($history as $record) {
            $progress = ($record['data']['total_modules'] > 0) 
                ? round(($record['data']['passed_modules'] / $record['data']['total_modules']) * 100, 2)
                : 0;
            
            echo '<div class="card history-card">';
            echo '<div class="card-header">';
            echo '<h5>' . htmlspecialchars($record['academic_year']) . '</h5>';
            echo '</div>';
            echo '<div class="card-body">';
            echo '<div class="row">';
            echo '<div class="col-md-6">';
            echo '<p><strong>Program:</strong> ' . htmlspecialchars($record['data']['program_name']) . '</p>';
            echo '<p><strong>Level:</strong> ' . htmlspecialchars($record['data']['level']) . '</p>';
            echo '<p><strong>Class:</strong> ' . htmlspecialchars($record['data']['class_code']) . '</p>';
            echo '</div>';
            echo '<div class="col-md-6">';
            echo '<p><strong>Status:</strong> <span class="badge ' . 
                 ($record['data']['status'] === 'active' ? 'bg-success' : 'bg-secondary') . '">' . 
                 htmlspecialchars($record['data']['status']) . '</span></p>';
            echo '<p><strong>Progress:</strong> ' . $record['data']['passed_modules'] . '/' . 
                 $record['data']['total_modules'] . ' modules passed</p>';
            echo '<div class="progress">';
            echo '<div class="progress-bar ' . ($progress >= 50 ? 'bg-success' : 'bg-warning') . '" 
                 role="progressbar" style="width: ' . $progress . '%" 
                 aria-valuenow="' . $progress . '" aria-valuemin="0" aria-valuemax="100">';
            echo $progress . '%';
            echo '</div>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
        }
        echo '</div>';
    } else {
        echo '<div class="alert alert-info">No academic history found for this student.</div>';
    }
} else {
    echo '<div class="alert alert-danger">Invalid student ID provided.</div>';
}
?>