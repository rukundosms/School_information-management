<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ob_start();
include("connection.php");
session_start();

// Verify teacher is logged in
if (!isset($_SESSION['tid'])) {
    header("location:index.html");
    exit();
}

// Verify all required session variables
$required_vars = ['tid', 'cl', 'module', 'year', 'tearm'];
foreach ($required_vars as $var) {
    if (!isset($_SESSION[$var])) {
        die("Missing required session variable: $var");
    }
}

$me = $_SESSION['tid'];
$class = $_SESSION['cl'];
$module = $_SESSION['module'];
$year = $_SESSION['year'];
$term = $_SESSION['tearm'];

// Get all students in the class
$allStudents = [];
$studentsQuery = mysqli_query($conn, "SELECT sid, firstname, lastname FROM student WHERE class='$class' ORDER BY firstname ASC");
if (!$studentsQuery) {
    die("Error fetching students: " . mysqli_error($conn));
}
while ($student = mysqli_fetch_assoc($studentsQuery)) {
    $allStudents[$student['sid']] = $student;
}

// Get existing marks for these students
$existingMarks = [];
$marksQuery = mysqli_query($conn, "SELECT * FROM marks WHERE tid='$me' AND mid='$module' AND cid='$class' AND team='$term'");
if (!$marksQuery) {
    die("Error fetching marks: " . mysqli_error($conn));
}
while ($mark = mysqli_fetch_assoc($marksQuery)) {
    $existingMarks[$mark['sid']] = $mark;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Marks</title>
    <style>
        body {
            font-family: sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            box-sizing: border-box;
        }

        .cont {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 90%;
            max-width: 800px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        caption {
            font-size: 1.2em;
            font-weight: bold;
            margin-bottom: 10px;
            text-align: center;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
        }

        input[type="number"] {
            width: 60px;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            text-align: center;
        }

        #notification-bar {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 40px;
            text-align: center;
            line-height: 40px;
            color: white;
            z-index: 1000;
            opacity: 0;
            transition: opacity 0.3s ease-in-out;
            pointer-events: none;
        }

        .saving {
            background-color: #ffc107 !important;
        }

        .saved {
            background-color: #d4edda !important;
            transition: background-color 1s ease;
        }

        .error {
            background-color: #f8d7da !important;
        }

        .mark-input {
            transition: background-color 0.5s ease;
        }

        .new-student {
            background-color: #e8f5e9;
        }

        .controls {
            margin-bottom: 15px;
            display: flex;
            justify-content: space-between;
        }

        .btn {
            padding: 8px 16px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .btn-secondary {
            background-color: #2196F3;
        }

        @media (min-width: 768px) {
            .cont {
                width: 80%;
            }

            #notification-bar {
                width: 30%;
                left: auto;
                right: 0;
                border-radius: 5px 0 0 5px;
            }
        }
    </style>
</head>
<body>
    <div id="notification-bar"></div>
    <div class="cont">
        <div class="controls">
            <button class="btn btn-secondary" onclick="window.location.href='list.php'">Back to List</button>
            <button class="btn" onclick="saveAllMarks()">Save All Changes</button>
        </div>
        
        <form id="marksForm">
            <table border="2">
                <caption><?php
                    $sel = mysqli_query($conn, "SELECT * FROM class, module WHERE module.moid='$module' AND class.cid='$class'");
                    if (mysqli_num_rows($sel) > 0) {
                        $b = mysqli_fetch_array($sel);
                        echo htmlspecialchars($b['level'] . " " . $b['mname']);
                    }
                ?></caption>
                <tr><th colspan="6"><?php echo "Term " . htmlspecialchars($term) ?></th></tr>
                <tr><th>No</th><th>Names</th><th>Test</th><th>Total</th><th>Exam</th><th>Total</th></tr>
                <?php
                $no = 0;
                foreach ($allStudents as $sid => $student) {
                    $no++;
                    $hasMarks = isset($existingMarks[$sid]);
                    $markData = $hasMarks ? $existingMarks[$sid] : [
                        'test' => '',
                        'ttotal' => '',
                        'exam' => '',
                        'etotal' => ''
                    ];
                    ?>
                    <tr id="row-<?php echo $sid; ?>" class="<?php echo !$hasMarks ? 'new-student' : ''; ?>">
                        <td><?php echo $no ?></td>
                        <td><?php echo htmlspecialchars($student['firstname'] . " " . $student['lastname']) ?></td>
                        <td><input type="number" name="test_<?php echo $sid; ?>" value="<?php echo htmlspecialchars($markData['test']); ?>" class="mark-input" data-sid="<?php echo $sid; ?>" data-field="test" min="0" max="200"></td>
                        <td><input type="number" name="ttotal_<?php echo $sid; ?>" value="<?php echo htmlspecialchars($markData['ttotal']); ?>" class="mark-input" data-sid="<?php echo $sid; ?>" data-field="ttotal" min="0" max="100"></td>
                        <td><input type="number" name="exam_<?php echo $sid; ?>" value="<?php echo htmlspecialchars($markData['exam']); ?>" class="mark-input" data-sid="<?php echo $sid; ?>" data-field="exam" min="0" max="200"></td>
                        <td><input type="number" name="etotal_<?php echo $sid; ?>" value="<?php echo htmlspecialchars($markData['etotal']); ?>" class="mark-input" data-sid="<?php echo $sid; ?>" data-field="etotal" min="0" max="100"></td>
                    </tr>
                    <?php
                }
                ?>
            </table>
        </form>
    </div>

    <script>
        // Debounce function
        function debounce(func, wait) {
            let timeout;
            return function(...args) {
                clearTimeout(timeout);
                timeout = setTimeout(() => func.apply(this, args), wait);
            };
        }

        // Function to save mark changes
async function saveMark(inputElement, isNewRecord = false) {
    const originalValue = inputElement.value;
    const field = inputElement.dataset.field;
    const sid = inputElement.dataset.sid;
    
    // Validate input
    if (originalValue !== "" && (isNaN(originalValue) || originalValue < 0 || originalValue > 200)) {
        inputElement.value = inputElement.defaultValue;
        showNotification("Value must be between 0 and 100 or empty", "red");
        return false;
    }

    // Visual feedback
    inputElement.classList.add('saving');
    inputElement.classList.remove('saved', 'error');

    try {
        const formData = new FormData();
        formData.append('sid', sid);
        formData.append('field', field);
        formData.append('value', originalValue);
        formData.append('me', <?php echo json_encode($me); ?>);
        formData.append('module', <?php echo json_encode($module); ?>);
        formData.append('class', <?php echo json_encode($class); ?>);
        formData.append('term', <?php echo json_encode($term); ?>);
        formData.append('year', <?php echo json_encode($year); ?>);
        formData.append('is_new', isNewRecord ? '1' : '0');

        const response = await fetch('save_markedit.php', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error(`Server returned ${response.status}`);
        }

        const data = await response.json();

        if (!data.success) {
            throw new Error(data.error || 'Unknown server error');
        }

        // Success - update default value
        inputElement.defaultValue = originalValue;
        inputElement.classList.add('saved');
        
        // If this was a new record and we successfully saved it, remove the "new" styling
        if (isNewRecord && data.action === 'insert') {
            const row = inputElement.closest('tr');
            row.classList.remove('new-student');
        }
        
        showNotification(data.message || "Changes saved successfully", "green");
        return true;

    } catch (error) {
        console.error('Save error:', error);
        inputElement.value = inputElement.defaultValue;
        inputElement.classList.add('error');
        showNotification("Error saving changes: " + error.message, "red");
        return false;

    } finally {
        setTimeout(() => {
            inputElement.classList.remove('saving');
        }, 500);
    }
}
        
        // Function to save all changes at once
        async function saveAllMarks() {
            const inputs = document.querySelectorAll('.mark-input');
            const notificationBar = document.getElementById('notification-bar');
            
            // Show saving notification
            notificationBar.textContent = "Saving all changes...";
            notificationBar.style.backgroundColor = "var(--warning-color)";
            notificationBar.style.opacity = 0.9;
            
            let successCount = 0;
            let errorCount = 0;
            
            // Process each input
            for (const input of inputs) {
                if (input.value !== input.defaultValue) {
                    try {
                        const isNewRecord = input.closest('tr').classList.contains('new-student');
                        const result = await saveMark(input, isNewRecord);
                        if (result) successCount++;
                        else errorCount++;
                    } catch (e) {
                        errorCount++;
                    }
                }
            }
            
            // Show final notification
            if (errorCount === 0) {
                notificationBar.textContent = `Successfully saved ${successCount} changes`;
                notificationBar.style.backgroundColor = "var(--success-color)";
            } else {
                notificationBar.textContent = `Saved ${successCount} changes, ${errorCount} failed`;
                notificationBar.style.backgroundColor = "var(--error-color)";
            }
            
            setTimeout(() => {
                notificationBar.style.opacity = 0;
            }, 3000);
        }

        // Notification function
        function showNotification(message, color) {
            const notificationBar = document.getElementById('notification-bar');
            notificationBar.textContent = message;
            notificationBar.style.backgroundColor = color;
            notificationBar.style.opacity = 0.9;

            setTimeout(() => {
                notificationBar.style.opacity = 0;
            }, 3000);
        }

        // Initialize with debounced save
        const debouncedSave = debounce(saveMark, 500);

        // Set up event listeners when DOM is loaded
        document.addEventListener('DOMContentLoaded', function() {
            const inputs = document.querySelectorAll('.mark-input');
            
            inputs.forEach(input => {
                // Store initial value
                input.defaultValue = input.value;
                
                // Save on change (with debounce)
                input.addEventListener('change', () => debouncedSave(input));
                
                // Save on blur (immediately)
                input.addEventListener('blur', function() {
                    if (this.value !== this.defaultValue) {
                        const isNewRecord = this.closest('tr').classList.contains('new-student');
                        saveMark(this, isNewRecord);
                    }
                });
                
                // Handle Enter key to move to next field
                input.addEventListener('keydown', function(e) {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        const isNewRecord = this.closest('tr').classList.contains('new-student');
                        saveMark(this, isNewRecord);
                        
                        // Move to next input field
                        const currentCell = this.closest('td');
                        const nextCell = currentCell.nextElementSibling;
                        if (nextCell) {
                            const nextInput = nextCell.querySelector('input');
                            if (nextInput) nextInput.focus();
                        }
                    }
                });
            });
        });
    </script>
</body>
</html>
<?php
ob_end_flush();
?>