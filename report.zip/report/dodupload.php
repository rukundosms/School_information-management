<style>
button {
    width: fit-content;
    height: fit-content;
    background-color: rgb(71, 231, 71);
    border: none;
    margin-top: 0.4rem;
    border-radius: 3px;
    padding: 5px;
    font-size: 20px;
    font-weight: bold;
    cursor: pointer;
    color: #fff;
}

.fail button {
    margin: 0;
    margin-top: 5px;
}

.error {
    width: 100%;
    background-color: rgb(243, 202, 208);
    color: black;
    font-size: 20px;
    height: fit-content;
    border-radius: 5px;
    font-weight: bold;
    padding: 5px;
    padding-top: 3rem;
    padding-bottom: 3rem;

    margin: auto;

}

.fail {
    width: 50%;
    height: fit-content;
    padding: 10px;
    margin: auto;
    border-radius: 5px;
    text-align: center;
}

.total {
    padding: 10px;
    font-size: 22px;
}

.totalinput {
    font-size: 12px;
    padding-top: 10px;
    padding-bottom: 10px;
    font-weight: bold;
}
</style>
<form action="" method="post">
    <?php
include("connection.php");
session_start();
if (!isset($_SESSION['id'])) {
    header("location:index.html");
 }
$class=$_SESSION['cl'];
$year=$_SESSION['year'];
$term=$_SESSION['term'];
if ($term==1) {
    $check=mysqli_query($conn,"SELECT * from conduct where class='$class' and year='$year' and term1>0");
    if (mysqli_num_rows($check)>0) {
        echo" <div class='fail'><div class='error'> this assessment aleady exist tap to 'view assessment' !!!</div>";
        echo"<button name='view'>view assessment</button></div>";
        if(isset($_POST['view'])){
            header("location:dodlist.php");
        }
        exit;
    }  
}
if ($term==2) {
    $check=mysqli_query($conn,"SELECT * from conduct where class='$class' and year='$year' and term2>0");
    if (mysqli_num_rows($check)>0) {
        echo" <div class='fail'><div class='error'> this assessment aleady exist tap to 'view assessment' !!!</div>";
        echo"<button name='view'>view assessment</button></div>";
        if(isset($_POST['view'])){
            header("location:dodlist.php");
        }
        exit;
    }  
}
if ($term==3) {
    $check=mysqli_query($conn,"SELECT * from conduct where class='$class' and year='$year' and term3>0");
    if (mysqli_num_rows($check)>0) {
        echo" <div class='fail'><div class='error'> this assessment aleady exist tap to 'view assessment' !!!</div>";
        echo"<button name='view'>view assessment</button></div>";
        if(isset($_POST['view'])){
            header("location:dodlist.php");
        }
        exit;
    }  
}


?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>upload</title>

    </head>

    <body>
        <center>
            <div class="cont">


                <?php

            
        echo"<table border='2'><caption>";
            $sel=mysqli_query($conn,"SELECT *from class where cid='$class'");
            $b=mysqli_fetch_array($sel);
            echo $b['level'].$b['class_name'];
            
            ?></caption>
                <tr>
                    <th colspan="2" class='total'>Max Point</th>
                    <th><input type="number" name="total" placeholder='Enter max point' class='totalinput' required>
                    </th>
                </tr>
                <tr>
                    <th>N<sup><u>0</u></sup></th>
                    <th>Names</th>
                    <th>mark</th>
                </tr>
                <?php
           $select=mysqli_query($conn,"SELECT * from student_promotion_log,student where
         student_promotion_log.to_class='$class' and student.sid=student_promotion_log.sid and 
         student_promotion_log.to_year='$year' order by student.firstname asc");
          $no=0;
        $name=0;
        $date=date('y/m/d');
        while ($a=mysqli_fetch_array($select)){
            $no++;
            $name++;
            echo"<tr><td>".$no."</td><td>".$a['firstname']." ".$a['lastname']."</td><td><input type='number' name='name{$name}' required></td></tr>";
            
            ?>
                <?php
            if (isset($_POST['upload'])){
                $mark= $_POST['name'.$name];
                $total= $_POST['total'];
               $sid=$a['sid'];
               if ($term==1) {
                $insert=mysqli_query($conn,"INSERT INTO conduct(year,term1,sid,class,total) values('$year','$mark','$sid','$class','$total')");
                header("location:dodlist.php");
               }
               if ($term==2) {
                $update=mysqli_query($conn,"UPDATE conduct set term2='$mark',class='$class' where sid='$sid'");
                header("location:dodlist.php");
               }
               if ($term==3) {
                $update=mysqli_query($conn,"UPDATE conduct set term3='$mark',class='$class' where sid='$sid'");
                header("location:dodlist.php");
               }
               
 
                }
               
            }
        
       
              
        echo"</table><button name='upload' id='u'>upload</button>"; 
                
               
        ?>




                <?php
 
?>
</form>
</div>
</center>
</body>

</html>