<?php
session_start();
// Check if user is logged in - using the correct session variable name
if (!isset($_SESSION['user_id']) || !isset($_SESSION['position'])) {
    header("Location: index.html");
    exit();
}

include("connection.php");

// Initialize all variables with default values
$online_users = [];
$online_teachers = [];
$current_year = null;
$current_year_id = null;
$current_year_label = 'Not Set';
$total_modules = 0;
$total_classes = 0;
$total_students = 0;
$assessed_modules = 0;
$students_missing_marks = 0;
$class_chart_data = [];
$module_chart_data = [];
$performance_chart_data = [];
$class_chart_json = '[]';
$module_chart_json = '[]';
$performance_chart_json = '[]';
$class_assessment_status = null;
$students_missing_marks_query = null;
$inactive_teachers = null;
$failed_students = null;
$modules_not_assessed = null;

// Fetch online logged-in users (with error handling)
if ($online_users_query = mysqli_query($conn, "SELECT username FROM users WHERE last_activity > DATE_SUB(NOW(), INTERVAL 5 MINUTE)")) {
    $online_users = mysqli_fetch_all($online_users_query, MYSQLI_ASSOC);
    mysqli_free_result($online_users_query);
}

// Fetch online teachers (with error handling)
$online_teachers_query = mysqli_query($conn, "SELECT t.teacher_id, t.teacher_code, t.first_name, t.last_name 
                                            FROM teachers t
                                            JOIN users u ON t.user_id = u.user_id
                                            JOIN user_roles ur ON u.role_id = ur.role_id
                                            WHERE ur.role_name = 'Teacher' AND u.last_activity > DATE_SUB(NOW(), INTERVAL 5 MINUTE)");
if ($online_teachers_query) {
    $online_teachers = mysqli_fetch_all($online_teachers_query, MYSQLI_ASSOC);
    mysqli_free_result($online_teachers_query);
}

// Get current academic year (with error handling)
$current_year_query = mysqli_query($conn, "SELECT * FROM academic_years WHERE is_current = 1");
if ($current_year_query && mysqli_num_rows($current_year_query) > 0) {
    $current_year = mysqli_fetch_assoc($current_year_query);
    $current_year_id = $current_year['academic_year_id'] ?? null;
    $current_year_label = $current_year['year_label'] ?? 'Not Set';
    mysqli_free_result($current_year_query);
}

// Statistics queries (with error handling)
if ($total_modules_result = mysqli_query($conn, "SELECT COUNT(*) as count FROM course_modules")) {
    $total_modules = mysqli_fetch_assoc($total_modules_result)['count'] ?? 0;
    mysqli_free_result($total_modules_result);
}

if ($total_classes_result = mysqli_query($conn, "SELECT COUNT(*) as count FROM classes")) {
    $total_classes = mysqli_fetch_assoc($total_classes_result)['count'] ?? 0;
    mysqli_free_result($total_classes_result);
}

if ($total_students_result = mysqli_query($conn, "SELECT COUNT(*) as count FROM students WHERE status = 'active'")) {
    $total_students = mysqli_fetch_assoc($total_students_result)['count'] ?? 0;
    mysqli_free_result($total_students_result);
}

// Only proceed with assessment data if we have a current academic year
if ($current_year_id) {
    // General assessment stats
    if ($assessed_modules_result = mysqli_query($conn, 
        "SELECT COUNT(DISTINCT module_id) as count FROM student_marks WHERE academic_year_id = $current_year_id")) {
        $assessed_modules = mysqli_fetch_assoc($assessed_modules_result)['count'] ?? 0;
        mysqli_free_result($assessed_modules_result);
    }
    
    // Students missing marks with class information
    $students_missing_marks_query = mysqli_query($conn, 
        "SELECT s.student_id, s.registration_number, s.first_name, s.last_name, 
                c.class_code, p.program_name, p.program_code
         FROM students s
         JOIN classes c ON s.current_class_id = c.class_id
         JOIN programs p ON c.program_id = p.program_id
         WHERE s.status = 'active' AND NOT EXISTS (
             SELECT 1 FROM student_marks sm 
             WHERE sm.student_id = s.student_id 
             AND sm.academic_year_id = $current_year_id
         )");
    if ($students_missing_marks_query) {
        $students_missing_marks = mysqli_num_rows($students_missing_marks_query);
    }
    
    // Teachers who haven't entered assessments
    $inactive_teachers = mysqli_query($conn, 
        "SELECT t.teacher_id, t.teacher_code, t.first_name, t.last_name 
         FROM teachers t
         WHERE NOT EXISTS (
             SELECT 1 FROM student_marks sm 
             WHERE sm.teacher_id = t.teacher_id
             AND sm.academic_year_id = $current_year_id
         )");
    
    // Failed students per module
    $failed_students = mysqli_query($conn,
        "SELECT cm.module_code, cm.module_name, COUNT(*) as failed_count
         FROM student_marks sm
         JOIN course_modules cm ON sm.module_id = cm.module_id
         WHERE sm.academic_year_id = $current_year_id
         AND sm.total_score < (sm.maximum_score * 0.5)  -- Assuming 50% is passing
         GROUP BY cm.module_id
         ORDER BY failed_count DESC");
    
    // Modules not assessed with program and level information
    $modules_not_assessed = mysqli_query($conn,
        "SELECT cm.module_code, cm.module_name, p.program_name, p.program_code, cm.level
         FROM course_modules cm
         JOIN programs p ON cm.program_id = p.program_id
         WHERE NOT EXISTS (
             SELECT 1 FROM student_marks sm
             WHERE sm.module_id = cm.module_id
             AND sm.academic_year_id = $current_year_id
         )
         ORDER BY p.program_name, cm.level");
    
    // Class-wise assessment completion
    $class_assessment_status = mysqli_query($conn,
        "SELECT c.class_id, c.class_code, p.program_name, p.program_code,
                COUNT(DISTINCT sm.module_id) as assessed_modules,
                COUNT(DISTINCT cm.module_id) as total_modules,
                COUNT(DISTINCT s.student_id) as total_students,
                COUNT(DISTINCT CASE WHEN sm.student_id IS NOT NULL THEN s.student_id END) as assessed_students
         FROM classes c
         JOIN programs p ON c.program_id = p.program_id
         JOIN students s ON c.class_id = s.current_class_id AND s.status = 'active'
         LEFT JOIN student_marks sm ON s.student_id = sm.student_id AND sm.academic_year_id = $current_year_id
         LEFT JOIN course_modules cm ON c.program_id = cm.program_id AND c.level = cm.level
         GROUP BY c.class_id
         ORDER BY p.program_name, c.class_code");
    
    // Class assessment data for chart
    $class_chart_query = mysqli_query($conn,
        "SELECT c.class_code, p.program_code,
                COUNT(DISTINCT sm.module_id) as assessed_modules,
                COUNT(DISTINCT cm.module_id) as total_modules
         FROM classes c
         JOIN programs p ON c.program_id = p.program_id
         LEFT JOIN students s ON c.class_id = s.current_class_id AND s.status = 'active'
         LEFT JOIN student_marks sm ON s.student_id = sm.student_id AND sm.academic_year_id = $current_year_id
         LEFT JOIN course_modules cm ON c.program_id = cm.program_id AND c.level = cm.level
         GROUP BY c.class_id
         ORDER BY p.program_name, c.class_code");
    
    if ($class_chart_query) {
        while ($row = mysqli_fetch_assoc($class_chart_query)) {
            $completion_rate = ($row['total_modules'] > 0) ? round(($row['assessed_modules'] / $row['total_modules']) * 100) : 0;
            $class_chart_data[] = [
                'class' => $row['program_code'] . ' ' . $row['class_code'],
                'completed' => $completion_rate,
                'remaining' => 100 - $completion_rate
            ];
        }
        $class_chart_json = json_encode($class_chart_data);
        mysqli_free_result($class_chart_query);
    }
    
    // Module assessment data for chart
    $module_chart_query = mysqli_query($conn,
        "SELECT p.program_code, cm.level,
                COUNT(DISTINCT CASE WHEN sm.module_id IS NOT NULL THEN cm.module_id END) as assessed_modules,
                COUNT(DISTINCT cm.module_id) as total_modules
         FROM course_modules cm
         JOIN programs p ON cm.program_id = p.program_id
         LEFT JOIN student_marks sm ON cm.module_id = sm.module_id AND sm.academic_year_id = $current_year_id
         GROUP BY p.program_id, cm.level
         ORDER BY p.program_name, cm.level");
    
    if ($module_chart_query) {
        while ($row = mysqli_fetch_assoc($module_chart_query)) {
            $completion_rate = ($row['total_modules'] > 0) ? round(($row['assessed_modules'] / $row['total_modules']) * 100) : 0;
            $module_chart_data[] = [
                'program' => $row['program_code'] . ' Level ' . $row['level'],
                'completed' => $completion_rate,
                'remaining' => 100 - $completion_rate
            ];
        }
        $module_chart_json = json_encode($module_chart_data);
        mysqli_free_result($module_chart_query);
    }
    
    // Student performance data for chart
    $performance_chart_query = mysqli_query($conn,
        "SELECT c.class_code, p.program_code,
                COUNT(DISTINCT s.student_id) as total_students,
                COUNT(DISTINCT CASE WHEN sm.total_score >= (sm.maximum_score * 0.5) THEN s.student_id END) as passed_students,
                COUNT(DISTINCT CASE WHEN sm.total_score < (sm.maximum_score * 0.5) THEN s.student_id END) as failed_students
         FROM classes c
         JOIN programs p ON c.program_id = p.program_id
         JOIN students s ON c.class_id = s.current_class_id AND s.status = 'active'
         LEFT JOIN student_marks sm ON s.student_id = sm.student_id AND sm.academic_year_id = $current_year_id
         GROUP BY c.class_id
         ORDER BY p.program_name, c.class_code");
    
    if ($performance_chart_query) {
        while ($row = mysqli_fetch_assoc($performance_chart_query)) {
            $passed = $row['passed_students'] ?? 0;
            $failed = $row['failed_students'] ?? 0;
            $total = $row['total_students'] ?? 0;
            $not_assessed = $total - ($passed + $failed);
            
            $performance_chart_data[] = [
                'class' => $row['program_code'] . ' ' . $row['class_code'],
                'passed' => $passed,
                'failed' => $failed,
                'not_assessed' => $not_assessed
            ];
        }
        $performance_chart_json = json_encode($performance_chart_data);
        mysqli_free_result($performance_chart_query);
    }
}

// Prepare the iframe content with proper escaping
$iframe_content = '<!DOCTYPE html>
<html>
<head>
    <style>
        /* Include all the styles from the parent document */
        :root {
            --primary-color: rgb(8, 58, 8);
            --secondary-color: wheat;
            --accent-color: rgba(255, 255, 255, 0.1);
            --text-light: #fff;
            --text-dark: #333;
            --bg-light: #f4f4f4;
            --bg-white: #fff;
            --border-color: #ddd;
            --success-color: #28a745;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
            --info-color: #17a2b8;
            --chart-color-1: #4e73df;
            --chart-color-2: #1cc88a;
            --chart-color-3: #36b9cc;
            --chart-color-4: #f6c23e;
            --chart-color-5: #e74a3b;
        }
        
        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
            font-family: \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--bg-light);
            min-height: 100vh;
        }

        .iframe-content {
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .dashboard-section {
            margin-bottom: 30px;
        }

        .dashboard-section h2 {
            color: var(--primary-color);
            margin-top: 0;
            margin-bottom: 15px;
            font-size: 1.3rem;
            font-weight: 600;
            border-bottom: 2px solid var(--primary-color);
            padding-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .stat-card {
            background-color: var(--bg-white);
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            border-left: 4px solid var(--primary-color);
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-card h3 {
            font-size: 1rem;
            color: var(--text-dark);
            margin-top: 0;
            margin-bottom: 10px;
            font-weight: 500;
        }

        .stat-card .stat-value {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 5px;
        }

        .stat-card .stat-label {
            font-size: 0.85rem;
            color: #666;
        }

        .progress-container {
            width: 100%;
            background-color: #e0e0e0;
            border-radius: 4px;
            margin: 10px 0;
            height: 20px;
        }
        
        .progress-bar {
            height: 100%;
            border-radius: 4px;
            background-color: var(--primary-color);
            transition: width 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 0.7rem;
            font-weight: bold;
        }
        
        .chart-container {
            position: relative;
            width: 100%;
            height: 300px;
            margin: 20px 0;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            padding: 15px;
        }

        .chart-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .chart-card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            padding: 20px;
        }

        .chart-card-header {
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--primary-color);
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .online-status-container {
            background-color: var(--bg-white);
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            border: 1px solid var(--border-color);
        }

        .no-online {
            color: #777;
            font-style: italic;
            font-size: 0.9rem;
            padding: 10px 0;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            font-size: 0.9rem;
        }

        .data-table th, .data-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }

        .data-table th {
            background-color: var(--primary-color);
            color: var(--text-light);
            font-weight: 600;
        }

        .student-class-badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 4px;
            background-color: var(--primary-color);
            color: white;
            font-size: 0.75rem;
            margin-left: 5px;
        }

        @media (max-width: 992px) {
            .chart-row {
                grid-template-columns: 1fr;
            }
        }
        
        .setup-message {
            background-color: #f8f9fa;
            border-left: 4px solid var(--primary-color);
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .setup-message h3 {
            color: var(--primary-color);
            margin-top: 0;
            margin-bottom: 10px;
        }
        
        .setup-message ul {
            margin-bottom: 0;
            padding-left: 20px;
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="iframe-content">
        <div class="dashboard-section">
            <h2><i class="fas fa-tachometer-alt"></i> Dashboard Overview</h2>
            <div class="stat-card info" style="margin-bottom: 20px;">
                <h3>Current Academic Year</h3>
                <div class="stat-value">'.htmlspecialchars($current_year_label).'</div>
                <div class="stat-label">'.($current_year_id ? "Active" : "Not set").'</div>
            </div>';
            
// Show setup message if no data exists
if ($total_modules == 0 && $total_classes == 0 && $total_students == 0) {
    $iframe_content .= '
            <div class="setup-message">
                <h3>Welcome to your new system!</h3>
                <p>It looks like you haven\'t set up any data yet. Here\'s what you need to do:</p>
                <ul>
                    <li>Set up the current academic year</li>
                    <li>Add your programs and classes</li>
                    <li>Create course modules</li>
                    <li>Register teachers and students</li>
                </ul>
                <p>Use the menu on the left to get started with the setup process.</p>
            </div>';
}

$iframe_content .= '
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Modules</h3>
                    <div class="stat-value">'.$total_modules.'</div>
                    <div class="stat-label">All available course modules</div>
                </div>
                
                <div class="stat-card">
                    <h3>Total Classes</h3>
                    <div class="stat-value">'.$total_classes.'</div>
                    <div class="stat-label">Active classes in the system</div>
                </div>
                
                <div class="stat-card">
                    <h3>Active Students</h3>
                    <div class="stat-value">'.$total_students.'</div>
                    <div class="stat-label">Currently enrolled students</div>
                </div>';
                
if ($current_year_id) {
    $modules_assessed_percent = ($total_modules > 0) ? round(($assessed_modules / $total_modules) * 100) : 0;
    $students_missing_percent = ($total_students > 0) ? round(($students_missing_marks / $total_students) * 100) : 0;
    
    $iframe_content .= '
                <div class="stat-card '.($assessed_modules < $total_modules ? 'warning' : 'success').'">
                    <h3>Assessment Progress</h3>
                    <div class="stat-value">'.$assessed_modules.'/'.$total_modules.'</div>
                    <div class="progress-container">
                        <div class="progress-bar '.($modules_assessed_percent < 50 ? 'danger' : ($modules_assessed_percent < 80 ? 'warning' : '')).'" 
                             style="width: '.$modules_assessed_percent.'%">
                            '.$modules_assessed_percent.'%
                        </div>
                    </div>
                    <div class="stat-label">Modules assessed this year</div>
                </div>
                
                <div class="stat-card '.($students_missing_marks > 0 ? 'danger' : 'success').'">
                    <h3>Students Missing Marks</h3>
                    <div class="stat-value">'.$students_missing_marks.'</div>
                    <div class="progress-container">
                        <div class="progress-bar '.($students_missing_percent > 50 ? 'danger' : ($students_missing_percent > 20 ? 'warning' : '')).'" 
                             style="width: '.$students_missing_percent.'%">
                            '.$students_missing_percent.'%
                        </div>
                    </div>
                    <div class="stat-label">Haven\'t been assessed yet</div>
                </div>';
}

$iframe_content .= '
            </div>
        </div>';
        
if ($current_year_id) {
    $iframe_content .= '
        <div class="dashboard-section">
            <h2><i class="fas fa-chart-line"></i> Performance Analytics</h2>
            
            <div class="chart-row">
                <div class="chart-card">
                    <div class="chart-card-header">
                        <i class="fas fa-check-circle"></i>
                        Class Assessment Completion
                    </div>
                    <div class="chart-container">
                        <canvas id="classCompletionChart"></canvas>
                    </div>
                </div>
                
                <div class="chart-card">
                    <div class="chart-card-header">
                        <i class="fas fa-book"></i>
                        Module Assessment Status
                    </div>
                    <div class="chart-container">
                        <canvas id="moduleCompletionChart"></canvas>
                    </div>
                </div>
            </div>
            
            <div class="chart-row">
                <div class="chart-card">
                    <div class="chart-card-header">
                        <i class="fas fa-user-graduate"></i>
                        Student Performance by Class
                    </div>
                    <div class="chart-container">
                        <canvas id="studentPerformanceChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="dashboard-section">
            <h2><i class="fas fa-chalkboard"></i> Class Assessment Status</h2>';
            
    if ($class_assessment_status && mysqli_num_rows($class_assessment_status) > 0) {
        mysqli_data_seek($class_assessment_status, 0); // Reset pointer
        while ($class = mysqli_fetch_assoc($class_assessment_status)) {
            $modules_assessed_percent = ($class["total_modules"] > 0) ? round(($class["assessed_modules"] / $class["total_modules"]) * 100) : 0;
            $students_assessed_percent = ($class["total_students"] > 0) ? round(($class["assessed_students"] / $class["total_students"]) * 100) : 0;
            
            $iframe_content .= '
            <div class="online-status-container">
                <h3>'.htmlspecialchars($class["program_name"]).' - '.htmlspecialchars($class["class_code"]).'</h3>
                
                <div class="class-progress">
                    <div class="class-progress-header">
                        <span class="class-progress-title">Modules Assessed</span>
                        <span class="class-progress-value">'.$class["assessed_modules"].'/'.$class["total_modules"].'</span>
                    </div>
                    <div class="progress-container">
                        <div class="progress-bar '.($modules_assessed_percent < 50 ? 'danger' : ($modules_assessed_percent < 80 ? 'warning' : '')).'" 
                             style="width: '.$modules_assessed_percent.'%">
                            '.$modules_assessed_percent.'%
                        </div>
                    </div>
                    <div class="completion-rate">
                        '.$class["assessed_modules"].' of '.$class["total_modules"].' modules assessed
                    </div>
                </div>
                
                <div class="class-progress">
                    <div class="class-progress-header">
                        <span class="class-progress-title">Students Assessed</span>
                        <span class="class-progress-value">'.$class["assessed_students"].'/'.$class["total_students"].'</span>
                    </div>
                    <div class="progress-container">
                        <div class="progress-bar '.($students_assessed_percent < 50 ? 'danger' : ($students_assessed_percent < 80 ? 'warning' : '')).'" 
                             style="width: '.$students_assessed_percent.'%">
                            '.$students_assessed_percent.'%
                        </div>
                    </div>
                    <div class="completion-rate">
                        '.$class["assessed_students"].' of '.$class["total_students"].' students assessed
                    </div>
                </div>
            </div>';
        }
    } else {
        $iframe_content .= '
            <div class="online-status-container">
                <p class="no-online">No class assessment data available for the current academic year.</p>
            </div>';
    }
    
    $iframe_content .= '
        </div>';
}

$iframe_content .= '
    </div>
    
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        // Class Completion Chart
        const classCtx = document.getElementById("classCompletionChart");
        if (classCtx) {
            new Chart(classCtx, {
                type: "bar",
                data: {
                    labels: '.$class_chart_json.'.map(item => item.class),
                    datasets: [{
                        label: "Completed %",
                        data: '.$class_chart_json.'.map(item => item.completed),
                        backgroundColor: "rgba(78, 115, 223, 0.8)",
                        borderColor: "rgba(78, 115, 223, 1)",
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 100,
                            title: {
                                display: true,
                                text: "Completion Percentage"
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: "Classes"
                            }
                        }
                    },
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return context.parsed.y + "% completed";
                                }
                            }
                        }
                    }
                }
            });
        }

        // Module Completion Chart
        const moduleCtx = document.getElementById("moduleCompletionChart");
        if (moduleCtx) {
            new Chart(moduleCtx, {
                type: "doughnut",
                data: {
                    labels: '.$module_chart_json.'.map(item => item.program),
                    datasets: [{
                        data: '.$module_chart_json.'.map(item => item.completed),
                        backgroundColor: [
                            "rgba(78, 115, 223, 0.8)",
                            "rgba(28, 200, 138, 0.8)",
                            "rgba(54, 185, 204, 0.8)",
                            "rgba(246, 194, 62, 0.8)",
                            "rgba(231, 74, 59, 0.8)"
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: "right",
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return context.raw + "% modules assessed";
                                }
                            }
                        }
                    }
                }
            });
        }

        // Student Performance Chart
        const performanceCtx = document.getElementById("studentPerformanceChart");
        if (performanceCtx) {
            new Chart(performanceCtx, {
                type: "bar",
                data: {
                    labels: '.$performance_chart_json.'.map(item => item.class),
                    datasets: [
                        {
                            label: "Passed",
                            data: '.$performance_chart_json.'.map(item => item.passed),
                            backgroundColor: "rgba(28, 200, 138, 0.8)",
                            borderWidth: 1
                        },
                        {
                            label: "Failed",
                            data: '.$performance_chart_json.'.map(item => item.failed),
                            backgroundColor: "rgba(231, 74, 59, 0.8)",
                            borderWidth: 1
                        },
                        {
                            label: "Not Assessed",
                            data: '.$performance_chart_json.'.map(item => item.not_assessed),
                            backgroundColor: "rgba(108, 117, 125, 0.8)",
                            borderWidth: 1
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        x: {
                            stacked: true,
                            title: {
                                display: true,
                                text: "Classes"
                            }
                        },
                        y: {
                            stacked: true,
                            title: {
                                display: true,
                                text: "Number of Students"
                            }
                        }
                    },
                    plugins: {
                        tooltip: {
                            callbacks: {
                                afterLabel: function(context) {
                                    const chart = context.chart;
                                    let total = 0;
                                    chart.data.datasets.forEach((ds) => {
                                        total += ds.data[context.dataIndex];
                                    });
                                    const percentage = total > 0 ? Math.round((context.raw / total) * 100) : 0;
                                    return "Percentage: " + percentage + "%";
                                }
                            }
                        }
                    }
                }
            });
        }
    });
    </script>
</body>
</html>';

// Escape the iframe content for proper HTML embedding
$escaped_iframe_content = htmlspecialchars($iframe_content, ENT_QUOTES);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>School Management Dashboard</title>
    <style>
        :root {
            --primary-color: rgb(8, 58, 8);
            --secondary-color: wheat;
            --accent-color: rgba(255, 255, 255, 0.1);
            --text-light: #fff;
            --text-dark: #333;
            --bg-light: #f4f4f4;
            --bg-white: #fff;
            --border-color: #ddd;
            --success-color: #28a745;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
            --info-color: #17a2b8;
            --chart-color-1: #4e73df;
            --chart-color-2: #1cc88a;
            --chart-color-3: #36b9cc;
            --chart-color-4: #f6c23e;
            --chart-color-5: #e74a3b;
        }
        
        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--bg-light);
            min-height: 100vh;
        }

        /* Container styles */
        .cont {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* Top bar styles */
        .top {
            background-color: var(--primary-color);
            color: var(--text-light);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 20px;
            position: relative;
            z-index: 10;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .top .s {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .top img {
            height: 40px;
            width: auto;
        }

        .top h1 {
            font-size: 1.2rem;
            font-weight: 500;
        }

        .user h1 {
            font-size: 1rem;
            font-weight: 500;
        }

        /* Center section styles */
        .center {
            display: flex;
            flex: 1;
            position: relative;
        }

        /* Sidebar styles */
        .left {
            background-color: var(--primary-color);
            color: var(--text-light);
            padding: 15px;
            width: 220px;
            overflow-y: auto;
            transition: all 0.3s ease;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }

        .left h1 {
            font-size: 1.2rem;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid var(--secondary-color);
            color: var(--secondary-color);
        }

        .left nav {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .left nav a {
            color: var(--text-light);
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 4px;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s ease;
        }

        .left nav a i {
            width: 20px;
            text-align: center;
        }

        .left nav a:hover {
            background-color: var(--accent-color);
            color: var(--secondary-color);
        }

        .left nav a.active {
            background-color: var(--accent-color);
            color: var(--secondary-color);
            font-weight: 600;
        }

        /* Iframe styles */
        iframe {
            flex: 1;
            background-color: var(--bg-white);
            border: none;
            min-height: calc(100vh - 70px);
        }

        /* Mobile menu toggle */
        .menu-toggle {
            display: none;
            background: none;
            border: none;
            color: var(--secondary-color);
            font-size: 1.5rem;
            cursor: pointer;
            padding: 5px;
        }

        /* Responsive styles */
        @media (max-width: 768px) {
            .menu-toggle {
                display: block;
            }
            
            .left {
                position: fixed;
                top: 64px;
                left: -220px;
                height: calc(100vh - 64px);
                z-index: 100;
            }
            
            .left.active {
                left: 0;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="cont">
        <div class="top">
            <div class="s">
                <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
                <img src="images/logo.jpg" alt="School Logo">
                <h1><?php
                    $info = mysqli_query($conn, "SELECT * from school_info");
                    if ($info && mysqli_num_rows($info) > 0) {
                        $i = mysqli_fetch_array($info);
                        echo htmlspecialchars($i['school_name']);
                    } else {
                        echo "School Management System";
                    }
                    ?></h1>
            </div>
            <div class="user">
                <h1><?php echo htmlspecialchars($_SESSION['username'] ?? 'User') ?></h1>
            </div>
        </div>
        <div class="center">
            <div class="left" id="sidebar">
                <h1>Menus</h1>
                <nav>
                    <a href="promotion_management.php" target="screen"><i class="fas fa-chalkboard-switching"></i>Switching</a>
                    <a href="teacher.php" target="screen"><i class="fas fa-chalkboard-teacher"></i> Teachers</a>
                    <a href="student_class.php" target="screen"><i class="fas fa-users"></i> Students</a>
                    <a href="class.php" target="screen"><i class="fas fa-door-open"></i> Class</a>
                    <a href="module.php" target="screen"><i class="fas fa-book"></i> Modules</a>
                    <a href="assessment.php" target="screen"><i class="fas fa-clipboard-check"></i> Assessment</a>
                    <a href="grant.php" target="screen"><i class="fas fa-key"></i> Grant</a>
                    <a href="revok.php" target="screen"><i class="fas fa-lock"></i> Revoke</a>
                    <a href="year.php" target="screen"><i class="fas fa-calendar-alt"></i> Academic Year</a>
                    <a href="rep.php" target="screen"><i class="fas fa-file-alt"></i> Report</a>
                    <a href="proclamation_year.php" target="screen"><i class="fas fa-trophy"></i> Ranking</a>
                    <a href="id_card.php" target="screen"><i class="fas fa-trophy"></i>card</a>
                    <a href="id_registration.php" target="screen"><i class="fas fa-trophy"></i>Registration_id</a>
                    <a href="school.php" target="screen"><i class="fas fa-school"></i> School</a>
                    <a href="profile.php" target="screen"><i class="fas fa-user"></i> Profile</a>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </nav>
            </div>
            <iframe srcdoc="<?php echo $escaped_iframe_content; ?>" frameborder="0" name="screen"></iframe>
        </div>
    </div>

    <script>
        // Toggle mobile menu
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        
        menuToggle.addEventListener('click', () => {
            sidebar.classList.toggle('active');
        });
        
        // Close menu when clicking outside on mobile
        document.addEventListener('click', (e) => {
            if (window.innerWidth <= 768 && !sidebar.contains(e.target) && e.target !== menuToggle) {
                sidebar.classList.remove('active');
            }
        });
        
        // Adjust iframe height on resize
        window.addEventListener('resize', () => {
            const topHeight = document.querySelector('.top').offsetHeight;
            document.querySelector('iframe').style.minHeight = `calc(100vh - ${topHeight}px)`;
        });

        // Set active menu item based on current page
        document.addEventListener('DOMContentLoaded', () => {
            const links = document.querySelectorAll('.left nav a');
            links.forEach(link => {
                if (link.href === window.location.href) {
                    link.classList.add('active');
                }
            });
        });
    </script>
</body>
</html>