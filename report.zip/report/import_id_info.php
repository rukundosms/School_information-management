<?php
include("connection.php");
require 'vendor/autoload.php'; // PhpSpreadsheet

use PhpOffice\PhpSpreadsheet\IOFactory;

$message = "";

if (isset($_POST['import'])) {
    if (!empty($_FILES['excel_file']['tmp_name'])) {
        $filePath = $_FILES['excel_file']['tmp_name'];

        try {
            $spreadsheet = IOFactory::load($filePath);
            $sheet = $spreadsheet->getActiveSheet();
            $rows = $sheet->toArray();

            $rowCount = 0;
            foreach ($rows as $index => $row) {
                // Skip header row
                if ($index == 0) continue;

                $reg_no       = trim($row[0] ?? '');
                $first_name   = trim($row[1] ?? '');
                $last_name    = trim($row[2] ?? '');
                $sex          = trim($row[3] ?? '');
                $level        = trim($row[4] ?? '');
                $class        = trim($row[5] ?? '');
                $academic_year= trim($row[6] ?? '');
                $school_name  = trim($row[7] ?? '');
                $school_phone = trim($row[8] ?? '');
                $school_email = trim($row[9] ?? '');

                if (!empty($reg_no) && !empty($first_name)) {
                    $stmt = $conn->prepare("INSERT INTO id_card 
                        (reg_no, first_name, last_name, sex, level, class, academic_year, school_name, school_phone, school_email) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->bind_param(
                        "ssssssssss",
                        $reg_no, $first_name, $last_name, $sex, $level, $class, 
                        $academic_year, $school_name, $school_phone, $school_email
                    );
                    $stmt->execute();
                    $stmt->close();
                    $rowCount++;
                }
            }
            $message = "<p style='color:green;'>Successfully imported $rowCount students!</p>";

        } catch (Exception $e) {
            $message = "<p style='color:red;'>Error reading Excel file: " . $e->getMessage() . "</p>";
        }
    } else {
        $message = "<p style='color:red;'>Please upload an Excel file.</p>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Import Students</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2>Upload Students from Excel</h2>
    <?= $message; ?>
    <form method="post" enctype="multipart/form-data" class="mt-3">
        <div class="mb-3">
            <label class="form-label">Choose Excel File (.xlsx or .xls)</label>
            <input type="file" name="excel_file" class="form-control" accept=".xlsx,.xls" required>
        </div>
        <button type="submit" name="import" class="btn btn-success">Import Students</button>
    </form>

    <hr>
    <p><strong>Expected Excel Format:</strong></p>
    <table class="table table-bordered">
        <tr>
            <th>Reg No</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Sex</th>
            <th>Level</th>
            <th>Class</th>
            <th>Academic Year</th>
            <th>School Name</th>
            <th>School Phone</th>
            <th>School Email</th>
        </tr>
        <tr>
            <td>2025-001</td>
            <td>John</td>
            <td>Doe</td>
            <td>M</td>
            <td>Level 1</td>
            <td>A</td>
            <td>2025</td>
            <td>TVET School</td>
            <td>+250123456</td>
            <td>school@email.com</td>
        </tr>
    </table>
</body>
</html>
