<?php
// admin.php - User Administration Panel
require_once 'connection.php'; // Database connection and session start

// Check if user is admin
// if (!isset($_SESSION['user_id']) || $_SESSION['role_id'] != 1) {
//     header("Location: index.html");
//     exit();
// }

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_user'])) {
        // Add new user
        $username = trim($_POST['username']);
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $role_id = (int)$_POST['role_id'];
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        $stmt = $conn->prepare("INSERT INTO users (username, password_hash, role_id, is_active) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssii", $username, $password, $role_id, $is_active);
        if ($stmt->execute()) {
            $success = "User added successfully!";
        } else {
            $error = "Error adding user: " . $conn->error;
        }
        
    } elseif (isset($_POST['update_user'])) {
        // Update existing user
        $user_id = (int)$_POST['user_id'];
        $username = trim($_POST['username']);
        $role_id = (int)$_POST['role_id'];
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        // Update password only if provided
        if (!empty($_POST['password'])) {
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET username=?, password_hash=?, role_id=?, is_active=? WHERE user_id=?");
            $stmt->bind_param("ssiii", $username, $password, $role_id, $is_active, $user_id);
        } else {
            $stmt = $conn->prepare("UPDATE users SET username=?, role_id=?, is_active=? WHERE user_id=?");
            $stmt->bind_param("siii", $username, $role_id, $is_active, $user_id);
        }
        
        if ($stmt->execute()) {
            $success = "User updated successfully!";
        } else {
            $error = "Error updating user: " . $conn->error;
        }
    }
} elseif (isset($_GET['delete'])) {
    // Delete user
    $user_id = (int)$_GET['delete'];
    
    $stmt = $conn->prepare("DELETE FROM users WHERE user_id=?");
    $stmt->bind_param("i", $user_id);
    if ($stmt->execute()) {
        $success = "User deleted successfully!";
    } else {
        $error = "Error deleting user: " . $conn->error;
    }
}

// Fetch all users with their role names
$users = [];
$result = $conn->query("
    SELECT u.*, r.role_name 
    FROM users u 
    JOIN user_roles r ON u.role_id = r.role_id
    ORDER BY u.user_id");

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
    $result->free();
}

// Fetch all roles for dropdowns
$roles = [];
$result = $conn->query("SELECT * FROM user_roles ORDER BY role_id");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $roles[] = $row;
    }
    $result->free();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - User Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-section { background: #f8f9fa; padding: 20px; border-radius: 5px; margin-bottom: 20px; }
        .table-responsive { margin-top: 20px; }
    </style>
</head>
<body>
    <div class="container mt-4">
        <h2 class="mb-4">User Management</h2>
        
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php elseif (isset($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <!-- Add/Edit User Form -->
        <div class="form-section">
            <h4><?= isset($_GET['edit']) ? 'Edit User' : 'Add New User' ?></h4>
            <form method="POST">
                <?php if (isset($_GET['edit'])): 
                    $result = $conn->query("SELECT * FROM users WHERE user_id=".(int)$_GET['edit']);
                    $edit_user = $result->fetch_assoc();
                ?>
                    <input type="hidden" name="user_id" value="<?= $edit_user['user_id'] ?>">
                <?php endif; ?>
                
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Username</label>
                        <input type="text" class="form-control" name="username" 
                            value="<?= isset($edit_user) ? htmlspecialchars($edit_user['username']) : '' ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Password</label>
                        <input type="password" class="form-control" name="password" 
                            placeholder="<?= isset($edit_user) ? 'Leave blank to keep current' : '' ?>" 
                            <?= !isset($edit_user) ? 'required' : '' ?>>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Role</label>
                        <select class="form-select" name="role_id" required>
                            <?php foreach ($roles as $role): ?>
                                <option value="<?= $role['role_id'] ?>" 
                                    <?= (isset($edit_user) && $edit_user['role_id'] == $role['role_id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($role['role_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <div class="form-check mt-4 pt-2">
                            <input class="form-check-input" type="checkbox" name="is_active" id="is_active" 
                                <?= (isset($edit_user) && $edit_user['is_active']) ? 'checked' : '' ?>>
                            <label class="form-check-label" for="is_active">Active User</label>
                        </div>
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary" name="<?= isset($_GET['edit']) ? 'update_user' : 'add_user' ?>">
                            <?= isset($_GET['edit']) ? 'Update User' : 'Add User' ?>
                        </button>
                        <?php if (isset($_GET['edit'])): ?>
                            <a href="admin.php" class="btn btn-secondary">Cancel</a>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
        
        <!-- Users List -->
        <div class="table-responsive">
            <h4>Existing Users</h4>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Last Login</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?= $user['user_id'] ?></td>
                            <td><?= htmlspecialchars($user['username']) ?></td>
                            <td><?= htmlspecialchars($user['role_name']) ?></td>
                            <td><?= $user['last_login'] ? date('Y-m-d H:i', strtotime($user['last_login'])) : 'Never' ?></td>
                            <td><?= $user['is_active'] ? 'Active' : 'Inactive' ?></td>
                            <td>
                                <a href="admin_creation.php?edit=<?= $user['user_id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                                <a href="admin_creation.php?delete=<?= $user['user_id'] ?>" class="btn btn-sm btn-danger" 
                                    onclick="return confirm('Are you sure you want to delete this user?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>