<?php
include("connection.php");
session_start();
if (!isset($_SESSION['id'])) {
    header("location:index.html");
}
$class = $_SESSION['cl'];
$year = $_SESSION['year'];
$term = $_SESSION['term'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Conduct</title>
</head>

<body>
    <center>
        <div class="cont">
            <form action="" method="post">
                <table border="2">
                    <caption><?php
            $sel = mysqli_query($conn, "SELECT * from class where cid='$class'");
            if (mysqli_num_rows($sel) > 0) {
                $b = mysqli_fetch_array($sel);
                echo $b['level'].$b['class_name'];
            }
            ?></caption>
                    <tr>
                        <th colspan="5"><?php echo "Term ".$term?></th>
                    </tr>
                    <tr>
                        <th>N<sup><u>0</u></sup></th>
                        <th>Names</th>
                        <th>Marks</th>
                        <th>Total</th>
                        <th>Status</th>
                    </tr>

                    <?php
            // Get all active students in this class
            $active_students=mysqli_query($conn,"SELECT * from student_promotion_log,student where
         student_promotion_log.to_class='$class' and student.sid=student_promotion_log.sid and 
         student_promotion_log.to_year='$year' order by student.firstname asc");
            $no = 0;
            $list = 0;
            
            while ($student = mysqli_fetch_array($active_students)) {
                $no++;
                $list++;
                $sid = $student['sid'];
                
                // Check if conduct record exists for this student
                $conduct_query = mysqli_query($conn, "SELECT * FROM conduct WHERE class='$class' AND sid='$sid' AND year='$year'");
                
                if (mysqli_num_rows($conduct_query) > 0) {
                    // Conduct record exists - display with current values
                    $a = mysqli_fetch_array($conduct_query);
                    $mark = $a['marks_id'];
                    ?>
                    <tr>
                        <td><?php echo $no ?></td>
                        <td><?php echo $student['firstname'] . " " . $student['lastname'] ?></td>
                        <td><input type="number" name="t<?php echo $list?>" value="<?php 
                            if ($term == 1) echo $a['term1'];
                            if ($term == 2) echo $a['term2'];
                            if ($term == 3) echo $a['term3'];
                        ?>"></td>
                        <td><input type="number" name="tt<?php echo $list?>" value="<?php echo $a['total'] ?>"></td>
                        <td>Existing Record</td>
                        <input type="hidden" name="sid<?php echo $list?>" value="<?php echo $sid ?>">
                        <input type="hidden" name="mark<?php echo $list?>" value="<?php echo $mark ?>">
                    </tr>
                    <?php
                } else {
                    // No conduct record exists - display with empty values
                    ?>
                    <tr>
                        <td><?php echo $no ?></td>
                        <td><?php echo $student['firstname'] . " " . $student['lastname'] ?></td>
                        <td><input type="number" name="t<?php echo $list?>" value=""></td>
                        <td><input type="number" name="tt<?php echo $list?>" value=""></td>
                        <td>New Record</td>
                        <input type="hidden" name="sid<?php echo $list?>" value="<?php echo $sid ?>">
                        <input type="hidden" name="mark<?php echo $list?>" value="new">
                    </tr>
                    <?php
                }
            }
            
            // Process form submission
            if (isset($_POST['edit'])) {
                for ($i = 1; $i <= $list; $i++) {
                    if (isset($_POST["t$i"]) && isset($_POST["sid$i"])) {
                        $t = $_POST["t$i"];
                        $total = $_POST["tt$i"];
                        $sid = $_POST["sid$i"];
                        $mark = $_POST["mark$i"];
                        
                        if ($mark == "new") {
                            // Insert new conduct record
                            $insert = mysqli_query($conn, "INSERT INTO conduct (sid, class, year, term1, term2, term3, total) 
                                                         VALUES ('$sid', '$class', '$year', 
                                                                 '".($term==1 ? $t : 0)."', 
                                                                 '".($term==2 ? $t : 0)."', 
                                                                 '".($term==3 ? $t : 0)."', 
                                                                 '$total')");
                        } else {
                            // Update existing conduct record
                            if ($term == 1) {
                                $update = mysqli_query($conn, "UPDATE conduct SET term1='$t', total='$total' WHERE marks_id='$mark'");
                            }
                            if ($term == 2) {
                                $update = mysqli_query($conn, "UPDATE conduct SET term2='$t', total='$total' WHERE marks_id='$mark'");
                            }
                            if ($term == 3) {
                                $update = mysqli_query($conn, "UPDATE conduct SET term3='$t', total='$total' WHERE marks_id='$mark'");
                            }
                        }
                    }
                }
                echo"<script>location='dodlist.php'</script>";
                exit();
            }
            ?>

                </table>

                <button name="edit">Save</button>
            </form>
        </div>
    </center>
</body>

</html>

<style>
input {
    width: 50px;
}

button {
    width: fit-content;
    height: fit-content;
    background-color: rgb(71, 231, 71);
    border: none;
    margin-top: 0.4rem;
    border-radius: 3px;
    padding: 5px;
    font-size: 20px;
    font-weight: bold;
    cursor: pointer;
    color: #fff;
}
</style>